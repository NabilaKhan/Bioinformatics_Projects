#include "./inc/RNAstructure.h"
#include "./inc/Parameters.h"
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

using namespace std;

void RNAstructure::RNAReadFile(string filename, int cutoff)	{
	register int i;
	char *tempHeader = new char[MAXSEQ];
	ifstream RNAstructureFile(filename.c_str());
	RNAstructureFile.getline(tempHeader, MAXSEQ);
	RNAstructureFile.close();
	if(tempHeader[0] == '>')	{
		//	the RNA structure is in Vienna format
		RNAstructure::ReadVienna(filename);
	}	else if(tempHeader[0] == '%')	{
		//	the RNA structure is in PS format (RNAfold output)
		RNAstructure::ReadRNAfoldPS(filename, cutoff);
	}	else	{
		cout << "Unrecognized RNA structure format!" << endl;
	}
	BuildArray();
	delete [] tempHeader;
	return;
}

void RNAstructure::ReadRNAfoldPS(string filename, int cutoff)	{

	register int i, j;
	
	char *readSeq = new char[MAXSEQ];
	string sequence, seqTag = "/sequence", lenTag = "/len", pairTag = "\%data", endTag = "showpage", ckheader;
	ifstream RNAstructureFile(filename.c_str());
	
	//	reads in the sequence
	do	{
		RNAstructureFile.getline(readSeq, MAXSEQ);
		ckheader = string(readSeq);
		ckheader = ckheader.substr(0,9);
	}	while(ckheader != seqTag && !RNAstructureFile.eof());
	do	{
		sequence += string(readSeq);
		RNAstructureFile.getline(readSeq, MAXSEQ);
		ckheader = string(readSeq);
		ckheader = ckheader.substr(0,4);
	}	while(ckheader != lenTag && !RNAstructureFile.eof());
	string::iterator it;
	for(it = sequence.begin(); it < sequence.end(); ++ it)	{
		if(isupper(*it))	{
			RNAstructure::RNAseq += *it;
		}
	}
	RNAseqlength = RNAseq.length();
	Parameters str2int;
	for(i = 0; i < RNAseqlength; ++ i)	{
		RNAseq[i] = (char) str2int.ncHash(RNAseq[i]);
	}
	
	//	reads in the base pairs
	do	{
		RNAstructureFile.getline(readSeq, MAXSEQ);
		ckheader = string(readSeq);
		ckheader = ckheader.substr(0,5);
	}	while(ckheader != pairTag && !RNAstructureFile.eof());
	
	int **pairholder = new int*[MAXSEQ];
	for(i = 0; i < MAXSEQ; ++ i)	{
		pairholder[i] = new int[3];
	}
	RNAnumPairs = 0;
	while(!RNAstructureFile.eof())	{
		RNAstructureFile.getline(readSeq, MAXSEQ);
		ckheader = string(readSeq);
		ckheader = ckheader.substr(0,8);
		if(ckheader == endTag)	{
			break;
		}	
		char *splitor;
		splitor = strtok(readSeq, " ");
		pairholder[RNAnumPairs][0] = atoi(splitor) - 1;
		splitor = strtok(NULL, " ");
		pairholder[RNAnumPairs][1] = atoi(splitor) - 1;
		splitor = strtok(NULL, " ");
		pairholder[RNAnumPairs][2] = floor(100 * atof(splitor));
		splitor = strtok(NULL, " ");
		if(pairholder[RNAnumPairs][2] >= cutoff && splitor[0] == 'u')	{
			++ RNAnumPairs;
		}
	}	
	RNAstructureFile.close();
	//	copy the base pairs
	RNApairs = new int *[RNAnumPairs];
	for(i = 0; i < RNAnumPairs; ++ i)	{
		RNApairs[i] = new int[3];
		for(j = 0; j < 3; ++ j)	{
			RNApairs[i][j] = pairholder[i][j];
		}
	}
	SortPairs();
	for(i = 0; i < MAXSEQ; ++ i)	{
		delete [] pairholder[i];
	}
	delete [] pairholder;
	delete [] readSeq;
	return;
}

void RNAstructure::ReadVienna(string filename)	{

	register int i;
	
	char *readHeader = new char[MAXSEQ];
	char *readSeq = new char[MAXSEQ];
	char *readStr = new char[MAXSEQ];
	
	//	open file and read in values	
	ifstream RNAstructureFile(filename.c_str());
	RNAstructureFile.getline(readHeader, MAXSEQ);
	RNAstructureFile.getline(readSeq, MAXSEQ);
	RNAstructureFile.getline(readStr, MAXSEQ);
	RNAstructureFile.close();

	//	format the information	
	RNAseqlength = strlen(readSeq);
	RNAheader = string(readHeader + 1);
	RNAseq = string(readSeq);
	Parameters str2int;
	for(i = 0; i < RNAseq.length(); ++ i)	{
		RNAseq[i] = (char) str2int.ncHash(RNAseq[i]);
	}

	stack<int*> tempPairs;
	stack<int> basepairs;
	RNAnumPairs = 0;
	for(i = 0; i < RNAseqlength; ++ i) {
		if(readStr[i] == '(') {
			basepairs.push(i);
		} else if(readStr[i] == ')' && !basepairs.empty())	{
			//	recording a base pair
			int *pair = new int[3];
			pair[0] = basepairs.top();
			basepairs.pop();
			pair[1] = i;
			pair[2] = 100;
			tempPairs.push(pair);
			++ RNAnumPairs;
		}
	}
	RNApairs = new int*[RNAnumPairs];
	for(i = 0; i < RNAnumPairs; ++ i)	{
		RNApairs[RNAnumPairs - i - 1] = tempPairs.top();
		tempPairs.pop();
	}
	SortPairs();
	delete [] readHeader;
	delete [] readSeq;
	delete [] readStr;
	return;

}


void RNAstructure::SortPairs(void)	{
	register int i, j;
	int temp;
	for(i = 0; i < RNAnumPairs - 1; ++ i)	{
		for(j = i + 1; j < RNAnumPairs; ++ j)	{
			if(RNApairs[i][1] > RNApairs[j][1] || 
			RNApairs[i][1] == RNApairs[j][1] && RNApairs[i][0] < RNApairs[j][0])	{
				//	swap
				temp = RNApairs[i][0];
				RNApairs[i][0] = RNApairs[j][0];
				RNApairs[j][0] = temp;
				temp = RNApairs[i][1];
				RNApairs[i][1] = RNApairs[j][1];
				RNApairs[j][1] = temp;
				temp = RNApairs[i][2];
				RNApairs[i][2] = RNApairs[j][2];
				RNApairs[j][2] = temp;
			}
		}
	}
	return;
}

void RNAstructure::BuildArray(void)	{
	register int i, j, k;
	
	//DEBUG
	/*
	for(i = 0; i < RNAnumPairs; ++ i)	{
		cout << i << "	" << RNApairs[i][0] << "	" << RNApairs[i][1] << endl;
	}
	cout << "*********************************************************" << endl;
	*/
	sizeDownArray = new int [RNAnumPairs];
	sizeUpArray = new int [RNAnumPairs];
	UpArrayHash = new int *[RNAnumPairs];
	DelLeftPair = new int* [RNAnumPairs];
	DelRightPair = new int* [RNAnumPairs];
	DelLeftPairConf = new int* [RNAnumPairs];
	DelRightPairConf = new int* [RNAnumPairs];
	DelPara = new int* [RNAnumPairs];
	DelParaDel = new int* [RNAnumPairs];
	DelHairpin = new int [RNAnumPairs];
	DelLeftBound = new int [RNAnumPairs];
	DelRightBound = new int [RNAnumPairs];
	for(i = 0; i < RNAnumPairs; ++ i)	{
		sizeDownArray[i] = sizeUpArray[i] = DelHairpin[i] = DelLeftBound[i] = DelRightBound[i] = 0;
		UpArrayHash[i] = new int [RNAnumPairs];
		DelLeftPair[i] = new int [RNAnumPairs];
		DelRightPair[i] = new int [RNAnumPairs];
		DelLeftPairConf[i] = new int [RNAnumPairs];
		DelRightPairConf[i] = new int [RNAnumPairs];
		DelPara[i] = new int [RNAnumPairs];
		DelParaDel[i] = new int [RNAnumPairs];
		for(j = 0; j < RNAnumPairs; ++ j)	{
			UpArrayHash[i][j] = -1;
			DelLeftPair[i][j] = DelRightPair[i][j] = DelLeftPairConf[i][j] = DelRightPairConf[i][j] = 0; 
			DelPara[i][j] = DelParaDel[i][j] = 0;
		}
	}	

	//	finding all enclosing relationship
	for(i = 0; i < RNAnumPairs - 1; ++ i)	{
		for(j = i + 1; j < RNAnumPairs; ++ j)	{
			if(RNApairs[j][0] <= RNApairs[i][0] && RNApairs[j][1] >= RNApairs[i][1])	{
				++ sizeDownArray[j];
				UpArrayHash[i][j] = sizeUpArray[i];
				++ sizeUpArray[i];
			}
		}
	}
	
	//	find all basepair deletions before, under, and after each base pair
	for(i = 0; i < RNAnumPairs; ++ i)	{
		for(j = 0; j < RNAnumPairs; ++ j)	{
			if(RNApairs[j][1] <= RNApairs[i][0])	{
				DelLeftBound[i] += RNApairs[j][2];
			}	else if(RNApairs[j][1] < RNApairs[i][1] || RNApairs[j][1] == RNApairs[i][1] && RNApairs[j][0] > RNApairs[i][0])	{
				DelHairpin[i] += RNApairs[j][2];
			}	else if(RNApairs[j][1] > RNApairs[i][1] || RNApairs[j][1] == RNApairs[i][1] && RNApairs[j][0] < RNApairs[i][0])	{
				DelRightBound[i] += RNApairs[j][2];
			}
		}
	}
	
	//	find all enclosing base pair deletion and parallel deletion
	for(i = 0; i < RNAnumPairs; ++ i)	{
		for(j = 0; j < RNAnumPairs; ++ j)	{
			for(k = 0; k < RNAnumPairs; ++ k)	{
				if(RNApairs[j][0] <= RNApairs[i][0] && RNApairs[j][1] >= RNApairs[i][1])	{
				//	case of enclosing
					if(RNApairs[k][1] <= RNApairs[i][0] && RNApairs[k][1] > RNApairs[j][0])	{
						DelLeftPair[i][j] += RNApairs[k][2];
					}	else if(RNApairs[k][1] <= RNApairs[i][0] && RNApairs[k][1] >= RNApairs[j][0])	{
						DelLeftPairConf[i][j] += RNApairs[k][2];
					}	else if(RNApairs[k][1] < RNApairs[j][1] && (RNApairs[k][1] > RNApairs[i][1] ||
								RNApairs[k][1] == RNApairs[i][1] && RNApairs[k][0] < RNApairs[i][0]))	{
						DelRightPair[i][j] += RNApairs[k][2];
					}	else if(RNApairs[k][1] <= RNApairs[j][1] && (RNApairs[k][1] > RNApairs[i][1] ||
								RNApairs[k][1] == RNApairs[i][1] && RNApairs[k][0] < RNApairs[i][0]))	{
						DelRightPairConf[i][j] += RNApairs[k][2];
					}
				}	else if(RNApairs[j][1] <= RNApairs[i][0])	{
				//	case of parallel
					if(RNApairs[k][1] <= RNApairs[i][0] && (RNApairs[k][1] > RNApairs[j][1] ||
						RNApairs[k][1] == RNApairs[j][1] && RNApairs[k][0] < RNApairs[j][0]))	{
						DelPara[i][j] += RNApairs[k][2];
					}	else if(RNApairs[k][1] <= RNApairs[i][1] && (RNApairs[k][1] > RNApairs[j][1] ||
						RNApairs[k][1] == RNApairs[j][1] && RNApairs[k][0] < RNApairs[j][0]))	{
						DelParaDel[j][i] += RNApairs[k][2];
					}
				}	
			}
		}
	}
	/*
	cout << "Del right pairs:" << endl;
	for(i = 0; i < RNAnumPairs; ++ i)	{
		for(j = 0; j < RNAnumPairs; ++ j)	{
			cout << DelRightPair[i][j] << "	";
		}
		cout << endl;
	}
	*/
	return;
}
	


void RNAstructure::PrintContent(void)	{
	register int i, j;
	
	for(i = 0; i < RNAnumPairs; ++ i)	{
		cout << RNApairs[i][0] << "	" << RNApairs[i][1] << "	" << RNApairs[i][2] << "	" << endl;
	}
	
	
	return;
}

RNAstructure::RNAstructure(string filename) {
	RNAheader = "InputRNA";
	RNAReadFile(filename, 950);
	return;
}

RNAstructure::RNAstructure(string filename, int cutoff) {
	RNAheader = "InputRNA";
	RNAReadFile(filename, cutoff);
	return;
}

RNAstructure::~RNAstructure(void) {
	//	please call collectMem(void) instead
	return;	
}

void RNAstructure::collectMem(void)	{
	//cout << "called collect RNAstructure memory" << endl;
	register int i;
	for(i = 0; i < RNAnumPairs; ++ i)	{
		delete [] RNApairs[i];
		delete [] UpArrayHash[i];
		delete [] DelLeftPair[i];
		delete [] DelRightPair[i];
		delete [] DelLeftPairConf[i];
		delete [] DelRightPairConf[i];
		delete [] DelPara[i];
		delete [] DelParaDel[i];
	}
	delete [] RNApairs;
	delete [] UpArrayHash;
	delete [] sizeDownArray;
	delete [] sizeUpArray;
	delete [] DelLeftPair;
	delete [] DelRightPair;
	delete [] DelLeftPairConf;
	delete [] DelRightPairConf;
	delete [] DelPara;
	delete [] DelParaDel;
	delete [] DelHairpin;
	delete [] DelLeftBound;
	delete [] DelRightBound;
	
	return;
}


