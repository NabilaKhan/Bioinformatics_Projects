#include "./inc/SequenceAlignment.h"
#include "assert.h"

using namespace std;

SequenceAlignment::SequenceAlignment(bool record, string A, string B, Parameters P){
	
	SeqA = A;
	SeqB = B;
	Score = P;
	recordTable = record;
	
	int maxLen = SeqA.length() + SeqB.length() + 1;
	CC.resize(maxLen);
	DD.resize(maxLen);
	RR.resize(maxLen);
	SS.resize(maxLen);
	Sapp.resize(maxLen);
	if(record)	{
		register int i;
		alnScore.resize(SeqA.length() + 1);
		for(i = 0; i < SeqA.length() + 1; ++ i)	{
			alnScore[i].resize(SeqB.length() + 1);
		}
	}
	
	return;
}

SequenceAlignment::~SequenceAlignment() {
	return;
}

char SequenceAlignment::int2char(int k)	{
	switch (k)	{
		case 0:
			return 'A';
			break;
		case 1:
			return 'C';
			break;
		case 2:
			return 'G';
			break;
		case 3:
			return 'U';
			break;
		default:
			cout << "corrupted sequence!	" << k << endl;
			exit(1);
	}
}

int SequenceAlignment::ALIGN(void)	{ 
	last = saptag = 0;
	int c = align(SeqA, SeqB, -Score.GAPST, -Score.GAPST);
	return c;
}

int SequenceAlignment::align(string A, string B, int tb, int te)	{
	int midi, midj, midc, type, c1, c2, t;
	register int   i, j;
	register int c, e, d, s;
	int M = A.length(), N = B.length();
	int g = Score.GAPST, h = Score.GAPET, m = g + h;
	//	Boundary cases: M <= 1 or N == 0
	if	(N <= 0)	{ 
		if (M > 0)	{
			DEL(M);
		}
		return -GAP(M, g, h);
	}
	if	(M <= 1)	{ 
		if (M <= 0)	{ 
			INS(N);
			return -GAP(N, g, h);
		}
		if	(tb < te)	tb = te;
		midc = (tb - h) - GAP(N, g, h);
		midj = 0;
		for	(j = 1; j <= N; ++ j)	{ 
			c = Score.Snc[(int) A[0]][(int) B[j - 1]] - GAP(j - 1, g, h) - GAP(N - j, g, h);
			if	(c > midc)	{
				midc = c;
				midj = j;
			}
		}
		if	(midj == 0)	{ 
			INS(N); 
			DEL(1); 
		}	else	{ 
			if (midj > 1)	{
				INS(midj - 1);
			}
			REP();
			if (midj < N)	{
				INS(N - midj);
			}
		}
		return midc;
	}
	//	Divide: Find optimum midpoint (midi,midj) of cost midc
	midi = M/2;		//	Forward phase
	CC[0] = 0;		//	Compute C(M/2,k) & D(M/2,k) for all k
	t = -g;
	for	(j = 1; j <= N; ++ j)	{ 
		CC[j] = t = t - h;
		DD[j] = t - g;
	}
	t = tb;
	for	(i = 1; i <= midi; ++ i)	{ 
		s = CC[0];
		CC[0] = c = t = t - h;
		e = t - g;
		for (j = 1; j <= N; ++ j)	{ 
			if ((c =   c   - m) > (e =   e   - h)) e = c;
			if ((c = CC[j] - m) > (d = DD[j] - h)) d = c;
			c = s + Score.Snc[(int) A[i - 1]][(int) B[j - 1]];
			if (e > c) c = e;
			if (d > c) c = d;
			s = CC[j];
			CC[j] = c;
			DD[j] = d;
		}
	}
	DD[0] = CC[0];

	RR[N] = 0;		//	Reverse phase:
	t = -g;			//	Compute R(M/2,k) & S(M/2,k) for all k
	for (j = N-1; j >= 0; -- j)	{ 
		RR[j] = t = t - h;
		SS[j] = t - g;
	}
	t = te;
	for (i = M-1; i >= midi; -- i)	{ 
		s = RR[N];
		RR[N] = c = t = t - h;
		e = t - g;
		for (j = N-1; j >= 0; -- j)	{ 
			if ((c =   c   - m) > (e =   e   - h)) e = c;
			if ((c = RR[j] - m) > (d = SS[j] - h)) d = c;
			c = s + Score.Snc[(int) A[i]][(int) B[j]];
			if (e > c) c = e;
			if (d > c) c = d;
			s = RR[j];
			RR[j] = c;
			SS[j] = d;
		}
	}
	SS[N] = RR[N];
	
	midc = CC[0] + RR[0];		// Find optimal midpoint
	midj = 0;
	type = 1;
	for (j = 0; j <= N; ++ j)	{
    	if ((c = CC[j] + RR[j]) >= midc)	{
			if (c > midc || CC[j] != DD[j] && RR[j] == SS[j])	{ 
				midc = c;
				midj = j;
			}
		}
	}        
	for (j = N; j >= 0; -- j)	{
		if ((c = DD[j] + SS[j] + g) > midc)	{
			midc = c;
			midj = j;
			type = 2;
		}
	}
	
	//	Conquer: recursively around midpoint
	if (type == 1)	{
		string subA1 = A.substr(0, midi);
		string subA2 = A.substr(midi, M - midi); 
		string subB1 = B.substr(0, midj);
		string subB2 = B.substr(midj, N - midj);
		c1 = align(subA1, subB1, tb, -g);
		c2 = align(subA2, subB2, -g, te);
    }	else	{
    	string subA1 = A.substr(0, midi - 1);
		string subA2 = A.substr(midi + 1, M - midi - 1); 
		string subB1 = B.substr(0, midj);
		string subB2 = B.substr(midj, N - midj);
		align(subA1, subB1, tb, 0);
		DEL(2);
		align(subA2, subB2, 0, te);
	}
	return midc;
}

//	TraceBack: similar to DISPLAY, but return the 3 arrays instead
void SequenceAlignment::TraceBack(string &alnA, string &alnB, string &symbol){
	register int i, j, op;
 	i = j = op = 0;
 	int lstag = 0;
 	int M = SeqA.length(), N = SeqB.length();
 	alnA = "", alnB = "", symbol = "";
  	while (i < M || j < N){ 
		if (op == 0 && Sapp[lstag] == 0){
			op = Sapp[lstag ++];
     		alnA += SeqA[i ++];
			alnB += SeqB[j ++];
			symbol += (SeqA[i - 1] == SeqB[j - 1]) ? '|' : ' ';
		}	else	{ 
			if	(op == 0)	{
				op = Sapp[lstag ++];
			}
			if	(op > 0)	{ 
				alnA += '-';
				alnB += SeqB[j ++];
				-- op;
			}	else	{ 
				alnA += SeqA[i ++];
				alnB += '-';
				++ op;
			}
			symbol += ' ';
		}			
	}
	for(i = 0; i < alnA.length(); ++ i)	{
		if(alnA[i] != '-')	{
			alnA[i] = int2char((int) alnA[i]);
		}
		if(alnB[i] != '-')	{
			alnB[i] = int2char((int) alnB[i]);
		}
	}
	return;
}

int SequenceAlignment::ComputeScore(void)	{
	register int i, j, k;
	register int t, c, e, d, s, m;
	int g = Score.GAPST, h = Score.GAPET;
	m = g + h;
	int lA = SeqA.length(), lB = SeqB.length();
	
	//	ToDo: add record for recordALNS, recordALNT, recordINS, recordDEL
	//	boundary cases
	if (lA <= 0)	{
		if(lB > 0)	{
			return (-g - lB * h);
		}	else if(lB == 0)	{
			return 0;
		}
	}	else	{
		if(lB <= 0)	{
			return (-g - lA * h);
		}
	}
	
	//	Initialization
	CC[0] = 0;
	t = -g;
	for (j = 1; j <= lB; j++)	{ 
		CC[j] = t = t - h;
		DD[j] = t - g;
    }
	t = -g;
	for (i = 1; i <= lA; i++)	{
		//	gets the matching score 
		s = CC[0];
		//	the score goes down
		CC[0] = c = t = t - h;
		//	the score goes right
		e = t - g;
		//	e represents the gap score comes from left
		//	DD represents the gap score comes from up
		for (j = 1; j <= lB; j++)	{
			//	in case the score comes from up 
			if ((c = c - m) > (e = e - h)) e = c;
			//	in case the score comes from match
			if ((c = CC[j] - m) > (d = DD[j] - h)) d = c;
			c = s + Score.Snc[(int) SeqA[i - 1]][(int) SeqB[j - 1]];
			//cout << Score.Snc[(int) SeqA[i - 1]][(int) SeqB[j - 1]] << endl;
			if (e > c) c = e;
			if (d > c) c = d;
			s = CC[j];
			CC[j] = c;
			DD[j] = d;
        }
    }
    int r = CC[lB];
    
    return r;
}

