#include "./inc/ResumeSeqAlignment.h"

using namespace std;

void ResumeSeqAlignment::ExtendNew(int &lenSup, int &lenSdown, int &lenTup, int &lenTdown,
		vector<int>& edgeScoreS, vector<int>& edgeScoreT, vector<int>& delScore, vector<int>& insScore)	{
	//	compute the sequence alignmnet scores from scratch
	//	will update lenSup, lenSdown, lenTup, lenTdown when finished
	//	will copy scores to edgeScoreS, edgeScoreT, delScore, insScore when finished
	
	register int i, j, k;
	register int t, c, e, d, s, m;
	int g = Score.GAPST, h = Score.GAPET;
	m = g + h;
	int lA = SeqA.length(), lB = SeqB.length();
	
	//	ToDo: add record for recordALNS, recordALNT, recordINS, recordDEL
	//	boundary cases
	if (lA <= 0)	{
		if(lB > 0)	{
			edgeScoreS[0] = 0;
			edgeScoreS[1] = edgeScoreT[0] = -m;
			delScore[1] = -m - g;
			alnScore[0][0] = 0;
			alnScore[0][1] = -m;
			for(j = 2; j <= lB; ++ j)	{
				edgeScoreS[j] = edgeScoreS[j - 1] - h;
				delScore[j] = edgeScoreS[j] - g;
				alnScore[0][j] = edgeScoreS[j];
			}
			//	edgeScoreT will represents score from the first column
			edgeScoreT[0] = 0;
			lenTup = lenTdown = 1;
			lenSup = lenSdown = lB + 1;
			return;
		}	else if(lB == 0)	{
			alnScore[0][0] = 0;	
			edgeScoreS[0] = edgeScoreT[0] = 0;
			lenSup = lenSdown = lenTup = lenTdown = 1;
			return;
		}
	}	else	{
		if(lB <= 0)	{
			edgeScoreT[0] = 0;
			edgeScoreT[1] = edgeScoreS[0] = -m;
			insScore[1] = -m - g;
			alnScore[0][0] = 0;
			alnScore[1][0] = -m;
			for(i = 2; i <= lA; ++ i)	{
				edgeScoreS[0] = edgeScoreT[i] = edgeScoreT[i - 1] - h;
				insScore[i] = edgeScoreT[i] - g;
				alnScore[i][0] = edgeScoreT[i];
			}
			lenSup = lenSdown = 1;
			lenTup = lenTdown = lA + 1;
			return;
		}
	}
	//	Initialization
	CC[0] = 0;
	alnScore[0][0] = 0;
	t = -g;
	for (j = 1; j <= lB; j++)	{ 
		CC[j] = t = t - h;
		DD[j] = t - g;
		alnScore[0][j] = CC[j];
    }
    edgeScoreT[0] = CC[j - 1];
	t = -g;
	for (i = 1; i <= lA; i++)	{
		//	gets the matching score 
		s = CC[0];
		//	the score goes down
		CC[0] = c = t = t - h;
		alnScore[i][0] = CC[0];
		//	the score goes right
		e = t - g;
		//	e represents the gap score comes from left
		//	DD represents the gap score comes from up
		for (j = 1; j <= lB; j++)	{
			//	in case the score comes from up 
			if ((c = c - m) > (e = e - h)) e = c;
			//	in case the score comes from match
			if ((c = CC[j] - m) > (d = DD[j] - h)) d = c;
			c = s + Score.Snc[(int) SeqA[i - 1]][(int) SeqB[j - 1]];
			//cout << Score.Snc[(int) SeqA[i - 1]][(int) SeqB[j - 1]] << endl;
			if (e > c) c = e;
			if (d > c) c = d;
			s = CC[j];
			CC[j] = c;
			DD[j] = d;
			alnScore[i][j] = CC[j];
        }
        if(i < lA)	{
        	edgeScoreT[i] = CC[j - 1];
        }
        insScore[i] = e;
    }
    for(j = 0; j <= lB; ++ j)	{
    	edgeScoreS[j] = CC[j];
    	delScore[j] = DD[j];
    }
    //	the last edgeScoreT will represents the score of the last row and first column
    edgeScoreT[lA] = alnScore[lA][0];
    lenSup = lenSdown = lB + 1;
    lenTup = lenTdown = lA + 1;
    
    return;
}

void ResumeSeqAlignment::ExtendFull(int &lenSup, int &lenSdown, int &lenTup, int &lenTdown,
		vector<int>& edgeScoreS, vector<int>& edgeScoreT, vector<int>& delScore, vector<int>& insScore)	{
	register int i, j, k;
	register int t, c, e, d, s, m;
	int g = Score.GAPST, h = Score.GAPET;
	m = g + h;
	int lA = SeqA.length(), lB = SeqB.length();
	
	//	Initialization of the first row
	int Tholder;
	t = Tholder = alnScore[0][0] = edgeScoreT[0];
	//	the score stored in edgeScore is not used
	//	safe to overwrite it
	edgeScoreT[lenTup - 1] = edgeScoreS[lenSdown - 1];
	if(lenSup == 1)	{
		t = -g;
	}

	for (j = lenSup; j <= lB;  ++ j)	{ 
		CC[j] = t = t - h;
		alnScore[0][j - lenSup + 1] = CC[j];
		DD[j] = t - g;
    }
 	edgeScoreT[0] = CC[j - 1];
    //	compute the top-right matrix
	for (i = 1; i < lenTup; ++ i)	{ 
		s = Tholder;
		c = Tholder = alnScore[i][0] = edgeScoreT[i];
		e = insScore[i];
		for (j = lenSup; j <= lB; ++ j)	{ 
			if ((c = c - m) > (e = e - h)) e = c;
			if ((c = CC[j] - m) > (d = DD[j] - h)) d = c;
			c = s + Score.Snc[(int) SeqA[i - 1]][(int) SeqB[j - 1]];
			if (e > c) c = e;
			if (d > c) c = d;
			s = CC[j - lenSup + 1];
			CC[j] = c;
			alnScore[i][j - lenSup + 1] = CC[j];
			DD[j] = d;
        }
       
        //	record the score of last column and insertion score
        //	no need to save edgeScoreT now, more cells to be filled in the following loop
        edgeScoreT[i] = CC[j - 1];
        insScore[i] = e;
    }

    //	copy the CC matrix to edgeScore, and the DD matrix to delScore
    for	(j = lenSup; j <= lB; ++ j)	{
    	edgeScoreS[j] = CC[j];
    	delScore[j] = DD[j];
    }
    //	copy the edgeScore to CC matrix
    for	(j = 0; j <= lB; ++ j)	{
    	CC[j] = alnScoreBackup[0][j] = edgeScoreS[j];
    	DD[j] = delScore[j];
    }

    //	compute the bottom matrix
    t = -g - (lenTdown - 1) * h;
    for (i = lenTdown; i <= lA; ++ i)	{ 
		s = CC[0];
		CC[0] = c = t = t - h;
		alnScoreBackup[i - lenTdown + 1][0] = CC[0];
		e = t - g;
		
		for (j = 1; j <= lB; ++ j)	{ 
			if ((c = c - m) > (e = e - h)) e = c;
			if ((c = CC[j] - m) > (d = DD[j] - h)) d = c;
			c = s + Score.Snc[(int) SeqA[i - 1]][(int) SeqB[j - 1]];
			if (e > c) c = e;
			if (d > c) c = d;
			s = CC[j];
			CC[j] = c;
			alnScoreBackup[i - lenTdown + 1][j] = CC[j];
			DD[j] = d;
        }
        //	save edgeScoreT for the previous alignment score
        if(i < lA)	{
        	edgeScoreT[i] = CC[j - 1];
        }
        insScore[i] = e;
    }
    
    //	copy the CC matrix to edgeScore, and the DD matrix to delScore
    for(j = 0; j <= lB; ++ j)	{
    	edgeScoreS[j] = CC[j];
    	delScore[j] = DD[j];
    }
    
    lenSup = lenSdown = lB + 1;
    lenTup = lenTdown = lA + 1;
    
	return;	
}

void ResumeSeqAlignment::ExtendRight(int &lenSup, int &lenSdown, int &lenTup, int &lenTdown,
		vector<int>& edgeScoreS, vector<int>& edgeScoreT, vector<int>& delScore, vector<int>& insScore)	{
	
	//	extends the alignment to the right (as SeqB gets longer)
	
	register int i, j, k;
	register int t, c, e, d, s, m;
	int g = Score.GAPST, h = Score.GAPET;
	m = g + h;
	int lA = SeqA.length(), lB = SeqB.length();
	
	//	Initialization of the first row
	//	safe to overwrite the last edgeScoreT
	edgeScoreT[lenTup - 1] = edgeScoreS[lenSdown - 1];
	int Tholder;
	t = Tholder = alnScore[0][0] = edgeScoreT[0];
	if(lenSup == 1)	{
		t = -g;
	}

	for (j = lenSup; j <= lB;  ++ j)	{ 
		CC[j - lenSup + 1] = t = t - h;
		alnScore[0][j - lenSup + 1] = CC[j - lenSup + 1];
		DD[j - lenSup + 1] = t - g;
    }
 	edgeScoreT[0] = CC[j - lenSup];
 
    //	compute the top-right matrix
	for (i = 1; i <= lA; ++ i)	{ 
		s = Tholder;
		c = Tholder = alnScore[i][0] = edgeScoreT[i];
		e = insScore[i];
		for (j = lenSup; j <= lB; ++ j)	{ 
			if ((c = c - m) > (e = e - h)) e = c;
			if ((c = CC[j - lenSup + 1] - m) > (d = DD[j - lenSup + 1] - h)) d = c;
			c = s + Score.Snc[(int) SeqA[i - 1]][(int) SeqB[j - 1]];
			if (e > c) c = e;
			if (d > c) c = d;
			s = CC[j - lenSup + 1];
			CC[j - lenSup + 1] = c;
			alnScore[i][j - lenSup + 1] = CC[j - lenSup + 1];
			DD[j - lenSup + 1] = d;
        }
        
        //	record the score of last column and insertion score
        if(i < lA)	{
	        edgeScoreT[i] = CC[j - lenSup];
        }
        insScore[i] = e;
    }

    //	copy the CC matrix to edgeScore, and the DD matrix to delScore
    for	(j = lenSup; j <= lB; ++ j)	{
    	edgeScoreS[j] = CC[j - lenSup + 1];
    	delScore[j] = DD[j - lenSup + 1];
    }
    
    lenSup = lB + 1;
    lenTup = lA + 1;
    if(lA + 1 == lenTdown)	{
    	lenSdown = lenSup;
    }

	return;
}

void ResumeSeqAlignment::ExtendDown(int &lenSup, int &lenSdown, int &lenTup, int &lenTdown,
		vector<int>& edgeScoreS, vector<int>& edgeScoreT, vector<int>& delScore, vector<int>& insScore)	{
	
	//	extends the alignment to the bottom (as SeqA gets longer)
	
	
	
	register int i, j, k;
	register int t, c, e, d, s, m;
	int g = Score.GAPST, h = Score.GAPET;
	m = g + h;
	int lA = SeqA.length(), lB = SeqB.length();
	
	//	safe to overwrite edgeScoreT
	edgeScoreT[lenTdown - 1] = edgeScoreS[lB];
 	//	copy the edgeScore to CC matrix
    for	(j = 0; j <= lB; ++ j)	{
    	CC[j] = alnScore[0][j] = edgeScoreS[j];
    	DD[j] = delScore[j];
    }

    //	compute the bottom matrix
    t = -g - (lenTdown - 1) * h;
    for (i = lenTdown; i <= lA; ++ i)	{ 
		s = CC[0];
		CC[0] = c = t = t - h;
		alnScore[i - lenTdown + 1][0] = CC[0];
		e = t - g;
		
		for (j = 1; j <= lB; ++ j)	{ 
			if ((c = c - m) > (e = e - h)) e = c;
			if ((c = CC[j] - m) > (d = DD[j] - h)) d = c;
			c = s + Score.Snc[(int) SeqA[i - 1]][(int) SeqB[j - 1]];
			if (e > c) c = e;
			if (d > c) c = d;
			s = CC[j];
			CC[j] = c;
			alnScore[i - lenTdown + 1][j] = CC[j];
			DD[j] = d;
        }
        if(i < lA)	{
        	edgeScoreT[i] = CC[j - 1];
        }
        insScore[i] = e;
    }
    
    //	copy the CC matrix to edgeScore, and the DD matrix to delScore
    for(j = 0; j <= lB; ++ j)	{
    	edgeScoreS[j] = CC[j];
    	delScore[j] = DD[j];
    }
    
    lenTdown = lA + 1;
    lenSdown = lB + 1;
    if(lB + 1 == lenSup)	{
    	lenTdown = lenTup;
    }
    
	return;
}


void ResumeSeqAlignment::ExtendDiagnoal(int &lenSup, int &lenSdown, int &lenTup, int &lenTdown,
		vector<int>& edgeScoreS, vector<int>& edgeScoreT, vector<int>& delScore, vector<int>& insScore)	{
	
	//	extends the alignment to the diagnoal 
	//	(assumes that ExtendRight and ExtendDown have already been called)
	
	register int i, j, k;
	register int t, c, e, d, s, m;
	int g = Score.GAPST, h = Score.GAPET;
	m = g + h;
	int Tholder;
	int lA = SeqA.length(), lB = SeqB.length();
	//	first copy the edgeScoreS to CC and DELScore to DD
    for	(j = lenSdown - 1; j <= lB; ++ j)	{
    	CC[j - lenSdown + 1] = alnScore[0][j - lenSdown + 1] = edgeScoreS[j];
    	DD[j - lenSdown + 1] = delScore[j];
    	//alnScore[lenTup - 1][j] = CC[j];
    }
    //	take the edgeScore From previous alignment
    alnScore[0][0] = Tholder = edgeScoreT[lenTup - 1];
    //	then overwrite it
    edgeScoreT[lenTup - 1] = edgeScoreS[lB];
    //	computes the unfilled diagnoal matrix
    for (i = lenTup; i <= lA; ++ i)	{ 
		s = Tholder;
		Tholder = c = alnScore[i - lenTup + 1][0] = edgeScoreT[i];
		//alnScore[i][lenSdown - 1] = CC[lenSdown - 1];
		e = insScore[i];
		for (j = lenSdown; j <= lB; ++ j)	{ 
			if ((c = c - m) > (e = e - h)) e = c;
			if ((c = CC[j - lenSdown + 1] - m) > (d = DD[j - lenSdown + 1] - h)) d = c;
			c = s + Score.Snc[(int) SeqA[i - 1]][(int) SeqB[j - 1]];
			if (e > c) c = e;
			if (d > c) c = d;
			s = CC[j - lenSdown + 1];
			CC[j - lenSdown + 1] = c;
			alnScore[i - lenTup + 1][j - lenSdown + 1] = CC[j - lenSdown + 1];
			DD[j - lenSdown + 1] = d;
        }
    	if(i < lA){
        	edgeScoreT[i] = CC[j - lenSdown];
        }
        insScore[i] = e;
    }
	//	record the edgeScoreS and deletion matrix
	for(j = lenSdown; j <= lB; ++ j)	{
		edgeScoreS[j] = CC[j - lenSdown + 1];
		delScore[j] = DD[j - lenSdown + 1];
	}
	
	if(lA + 1 == lenTdown)	{
		lenSdown = lB + 1;
		if(lenSdown == lenSup)	{
			lenTup = lenTdown;
		}
	}	else if(lB + 1 == lenSup)	{
		lenTup = lA + 1;
		if(lenTup == lenTdown)	{
			lenSdown = lenSup;
		}
	}
	return;
}
