#include <string>
#include "math.h"
#include "./inc/StructureAlignment.h"


using namespace std;

int compare(const void *a, const void *b)	{
	return (*(int*)a - *(int*)b);
}


char int2char(int k)	{
	switch (k)	{
		case 0:
			return 'A';
			break;
		case 1:
			return 'C';
			break;
		case 2:
			return 'G';
			break;
		case 3:
			return 'U';
			break;
		default:
			cout << "corrupted sequence!	" << k << endl;
			exit(1);
	}
}

void StructureAlignment::ReverseString(string &s)	{
	register int i, l = s.length();
	for(i = 0; i < l / 2; ++ i)	{
		char k = s[i];
		s[i] = s[l - i - 1];
		s[l - i - 1] = k;
	}
	return;
}

void StructureAlignment::PrintContent(void)	{
	cout << S.RNAnumPairs << endl;
	return;
}

StructureAlignment::StructureAlignment(RNAstructure s, RNAstructure t, Parameters P)	{
	register int i, j, k;
	S = s;
	T = t;
	Score = P;
	ActiveOPMhead = NULL;
	ActiveOPMtail = NULL;
	MAXOPMID = MAXNUMOPM = NUMOPM = 0;
	//	Initialize the DP table
	Table = new int* [S.RNAnumPairs];
	ContStacking = new int* [S.RNAnumPairs];
	Matched = new MPair* [S.RNAnumPairs];
	for(i = 0; i < S.RNAnumPairs; ++ i)	{
		Table[i] = new int [T.RNAnumPairs];
		ContStacking[i] = new int [T.RNAnumPairs];
		Matched[i] = new MPair [T.RNAnumPairs];
		for(j = 0; j < T.RNAnumPairs; ++ j)	{
			Table[i][j] = ContStacking[i][j] = 0;
			Matched[i][j].num = 0;
			Matched[i][j].coordinates = new int [S.RNAnumPairs + T.RNAnumPairs];
		}
	}

	return;
}



StructureAlignment::~StructureAlignment(void)	{

	register int i, j, k, l;

	//	collection of tables created in StructureAlignment
	for(i = 0; i < S.RNAnumPairs; ++ i)	{
		delete [] Table[i];
		delete [] ContStacking[i];
	}
	delete [] Table;
	delete [] ContStacking;
	for(i = 0; i < S.RNAnumPairs; ++ i)	{
		for(j = 0; j < T.RNAnumPairs; ++ j)	{
			delete [] Matched[i][j].coordinates;
		}
		delete [] Matched[i];
	}
	delete [] Matched;

	//	collection of the OPM list
	while(ActiveOPMhead != NULL)	{
		OPM *temp = ActiveOPMhead;
		ActiveOPMhead = ActiveOPMhead->next;
		CollectOPM(temp);
	}

	S.collectMem();
	T.collectMem();
	return;
}

void StructureAlignment::CollectOPM(OPM *crt)	{
	return;
}

int StructureAlignment::ComputeAppendScore(int Sout, int Tout, int Sin, int Tin)	{

	int leftS = S.RNApairs[Sin][0] - S.RNApairs[Sout][0];
	int leftT = T.RNApairs[Tin][0] - T.RNApairs[Tout][0];
	int rightS = S.RNApairs[Sout][1] - S.RNApairs[Sin][1];
	int rightT = T.RNApairs[Tout][1] - T.RNApairs[Tin][1];

	int left = leftS > leftT ? leftS : leftT;
	int right = rightS > rightT ? rightS : rightT;

	int minL = S.DelLeftPair[Sin][Sout] < T.DelLeftPair[Tin][Tout] ? S.DelLeftPair[Sin][Sout] : T.DelLeftPair[Tin][Tout];
	int minR = S.DelRightPair[Sin][Sout] < T.DelRightPair[Tin][Tout] ? S.DelRightPair[Sin][Sout] : T.DelRightPair[Tin][Tout];
	int DiffL = abs(S.DelLeftPair[Sin][Sout] - T.DelLeftPair[Tin][Tout]);
	int DiffR = abs(S.DelRightPair[Sin][Sout] - T.DelRightPair[Tin][Tout]);

	int score = (left + right) * Score.W3 * (Score.Snc[0][0] + Score.GAPET + Score.GAPST);
	//score += (int) Score.W1 * ((S.DelLeftPairConf[Sin][Sout] + T.DelLeftPairConf[Tin][Tout]) / 100);
	//score += (int) Score.W1 * ((S.DelRightPairConf[Sin][Sout] + T.DelRightPairConf[Tin][Tout]) / 100);

	//score += (int) Score.W1 * ((minL / 100) * Score.Sbp[0][0] - (DiffL / 100) * Score.BPDelete);
	//score += (int) Score.W1 * ((minR / 100) * Score.Sbp[0][0] - (DiffR / 100) * Score.BPDelete);

	return score;

}

void StructureAlignment::AddOPM(OPM *crtMATCH, int m1, int m2)	{

	//	what we need here is establish the F set
	//	and link the OPM to the list
	//	no sequence alignment computation is needed anymore

	register int i, j;
	++ NUMOPM;
	if(NUMOPM > MAXNUMOPM)	{
		MAXNUMOPM = NUMOPM;
	}

	//	mark m1, m2 as an OPM and add to the OPM chains
	crtMATCH->bpS = m1;
	crtMATCH->bpT = m2;
	crtMATCH->ID = MAXOPMID ++;
	crtMATCH->next = NULL;
	crtMATCH->prev = NULL;

	crtMATCH->LlenSup = crtMATCH->LlenSdown = crtMATCH->LlenTup = crtMATCH->LlenTdown = 0;
	crtMATCH->RlenSup = crtMATCH->RlenSdown = crtMATCH->RlenTup = crtMATCH->RlenTdown = 0;

	//	Confusion may exists in the naming of S and T, but this is not an error!!!
	//	I will fix the naming issue in the future.
	crtMATCH->LedgeScoreS.resize(T.RNApairs[m2][0] + 1);
	crtMATCH->LdelScore.resize(T.RNApairs[m2][0] + 1);
	crtMATCH->LedgeScoreT.resize(S.RNApairs[m1][0] + 1);
	crtMATCH->LinsScore.resize(S.RNApairs[m1][0] + 1);
	crtMATCH->RedgeScoreS.resize(T.RNAseqlength - T.RNApairs[m2][1] + 1);
	crtMATCH->RdelScore.resize(T.RNAseqlength - T.RNApairs[m2][1] + 1);
	crtMATCH->RedgeScoreT.resize(S.RNAseqlength - S.RNApairs[m1][1] + 1);
	crtMATCH->RinsScore.resize(S.RNAseqlength - S.RNApairs[m1][1] + 1);

	//	link the OPM to the list
	if(ActiveOPMhead == NULL)	{
		ActiveOPMhead = crtMATCH;
		ActiveOPMtail = crtMATCH;
	}	else	{
		ActiveOPMtail->next = crtMATCH;
		crtMATCH->prev = ActiveOPMtail;
		ActiveOPMtail = crtMATCH;
	}

	//	find the F set and record using the blinks
	OPM* crtITR = ActiveOPMtail->prev;
	int lboundS = -1, lboundT = -1;
	crtMATCH->numblinks = crtMATCH->numflinks = 0;
	map<int, int>::iterator it;

	while(crtITR != NULL)	{
		//	if the OPM satisfy the F set condition
		int n1 = crtITR->bpS, n2 = crtITR->bpT;

		if(S.RNApairs[n1][1] < S.RNApairs[m1][0] && T.RNApairs[n2][1] < T.RNApairs[m2][0] &&
			(S.RNApairs[n1][1] >= lboundS || T.RNApairs[n2][1] >= lboundT))	{

			//	update the left bound
			lboundS = S.RNApairs[n1][0] > lboundS ? S.RNApairs[n1][0] : lboundS;
			lboundT = T.RNApairs[n2][0] > lboundT ? T.RNApairs[n2][0] : lboundT;

			crtMATCH->blinks.resize(crtMATCH->numblinks + 1);
			crtMATCH->bLocator.resize(crtMATCH->numblinks + 1);
			//	construct the blinks
			crtMATCH->blinks[crtMATCH->numblinks] = crtITR;
			crtMATCH->bLocator[crtMATCH->numblinks] = crtITR->numflinks;

			crtITR->flinks.resize(crtITR->numflinks + 1);
			crtITR->fLocator.resize(crtITR->numflinks + 1);
			//	construct the flinks
			crtITR->flinks[crtITR->numflinks] = crtMATCH;
			crtITR->fLocator[crtITR->numflinks] = crtMATCH->numblinks;

			++ crtMATCH->numblinks;
			++ crtITR->numflinks;


		}	else if(S.RNApairs[n1][1] <= lboundS && T.RNApairs[n2][1] <= lboundT)	{
			break;
		}
		//	loops to the previous OPM
		crtITR = crtITR->prev;
	}

	crtMATCH->prevScore.resize(crtMATCH->numblinks);
	crtMATCH->prevScoreDel.resize(crtMATCH->numblinks);
	crtMATCH->prevFilled.resize(crtMATCH->numblinks);

	for(i = 0; i < crtMATCH->numblinks; ++ i)	{
		crtMATCH->prevScore[i] = crtMATCH->prevScoreDel[i] = 0;
		crtMATCH->prevFilled[i] = false;
	}

	return;
}


//	assume we dont need this function at this point
void StructureAlignment::DelOPM(OPM *crtDel)	{

	register int i, j, k;
	-- NUMOPM;

	//	find out whether the current OPM is being covered by other OPMs
	bool fullcover = false, Scover = false, Tcover = false;
	int ScoverPos = 0, TcoverPos = 0;

	OPM* crtCV = ActiveOPMtail;
	while(crtCV != NULL)	{
		if(crtCV->ID == crtDel->ID)	{
			crtCV = crtCV->prev;
			continue;
		}

		if((S.RNApairs[crtCV->bpS][0] >= S.RNApairs[crtDel->bpS][0] && S.RNApairs[crtCV->bpS][1] <= S.RNApairs[crtDel->bpS][1] ||
			S.RNApairs[crtCV->bpS][0] <= S.RNApairs[crtDel->bpS][0] && S.RNApairs[crtCV->bpS][1] >= S.RNApairs[crtDel->bpS][1])
			&&
			(T.RNApairs[crtCV->bpT][0] >= T.RNApairs[crtDel->bpT][0] && T.RNApairs[crtCV->bpT][1] <= T.RNApairs[crtDel->bpT][1] ||
			T.RNApairs[crtCV->bpT][0] <= T.RNApairs[crtDel->bpT][0] && T.RNApairs[crtCV->bpT][1] >= T.RNApairs[crtDel->bpT][1]))	{
			fullcover = true;
		}	else if(T.RNApairs[crtCV->bpT][0] >= T.RNApairs[crtDel->bpT][0] && T.RNApairs[crtCV->bpT][1] <= T.RNApairs[crtDel->bpT][1] ||
					T.RNApairs[crtCV->bpT][0] <= T.RNApairs[crtDel->bpT][0] && T.RNApairs[crtCV->bpT][1] >= T.RNApairs[crtDel->bpT][1])	{
			Scover = true;
			if(S.RNApairs[crtCV->bpS][0] > ScoverPos)	{
				ScoverPos = S.RNApairs[crtCV->bpS][0];
			}
		}	else if(S.RNApairs[crtCV->bpS][0] >= S.RNApairs[crtDel->bpS][0] && S.RNApairs[crtCV->bpS][1] <= S.RNApairs[crtDel->bpS][1] ||
					S.RNApairs[crtCV->bpS][0] <= S.RNApairs[crtDel->bpS][0] && S.RNApairs[crtCV->bpS][1] >= S.RNApairs[crtDel->bpS][1])	{
			Tcover = true;
			if(T.RNApairs[crtCV->bpT][0] > TcoverPos)	{
				TcoverPos = T.RNApairs[crtCV->bpT][0];
			}
		}
		crtCV = crtCV->prev;
	}

	//	based on the coverage construct appending OPM sets
	vector<OPM *> backwardOPM;
	backwardOPM.resize(crtDel->numblinks);
	int numbwOPM = 0;

	vector<int> backwardOPMnew;
	backwardOPMnew.resize(crtDel->numblinks);

	//	check for backward links: if fully covered then non, otherwise need to check
	if(!fullcover && !Scover && !Tcover)	{
		for(numbwOPM = 0; numbwOPM < crtDel->numblinks; ++ numbwOPM)	{
			backwardOPM[numbwOPM] = crtDel->blinks[numbwOPM];
		}
	}	else if(!fullcover && (Scover || Tcover))	{
		for(i = 0; i < crtDel->numblinks; ++ i)	{
			bool covered = false;
			if(Scover && S.RNApairs[crtDel->blinks[i]->bpS][1] < ScoverPos)	{
				covered = true;
			}
			if(Tcover && T.RNApairs[crtDel->blinks[i]->bpT][1] < TcoverPos)	{
				covered = true;
			}
			if(!covered)	{
				backwardOPM[numbwOPM] = crtDel->blinks[i];
				backwardOPMnew[numbwOPM] = i;
				++ numbwOPM;
			}
		}
	}


	map<int, int>::iterator it;

	//	remove the flinks of the blinks of the current deleting OPM
	for(i = 0; i < crtDel->numblinks; ++ i)	{
		OPM* aheadOPM = crtDel->blinks[i];
		//	gets the location of crtDel using Hash
		k = crtDel->bLocator[i];
		if(aheadOPM->numflinks < 1 || k < 0)	{
			break;
		}

		//	put the current flink as the last OPM
		aheadOPM->flinks[k] = aheadOPM->flinks[aheadOPM->numflinks - 1];
		aheadOPM->fLocator[k] = aheadOPM->fLocator[aheadOPM->numflinks - 1];
		aheadOPM->flinks[k]->bLocator[aheadOPM->fLocator[k]] = k;
		//	shrink the size of flinks by 1
		aheadOPM->flinks.resize(aheadOPM->numflinks - 1);
		aheadOPM->fLocator.resize(aheadOPM->numflinks - 1);
		//	adding the current entry to hash table
		-- aheadOPM->numflinks;
	}


	int *OldblinkScores = new int [crtDel->numflinks];
	int *OldblinkScoresDel = new int [crtDel->numflinks];
	//	remove the blinks of the flinks of the current deleting OPM
	for(i = 0; i < crtDel->numflinks; ++ i)	{
		OPM* afterOPM = crtDel->flinks[i];

		k = crtDel->fLocator[i];
		if(afterOPM->numblinks < 1 || k < 0)	{
			break;
		}
		//	put the current blink as the last OPM
		afterOPM->blinks[k] = afterOPM->blinks[afterOPM->numblinks - 1];
		afterOPM->bLocator[k] = afterOPM->bLocator[afterOPM->numblinks - 1];
		afterOPM->blinks[k]->fLocator[afterOPM->bLocator[k]] = k;
		//	shrink the size of blink by 1
		afterOPM->blinks.resize(afterOPM->numblinks - 1);
		afterOPM->bLocator.resize(afterOPM->numblinks - 1);
		//	record and update the blinkscores
		OldblinkScores[i] = afterOPM->prevScore[k];
		OldblinkScoresDel[i] = afterOPM->prevScoreDel[k];
		//	move the prevScore and prevScoreDel
		afterOPM->prevScore[k] = afterOPM->prevScore[afterOPM->numblinks - 1];
		afterOPM->prevScoreDel[k] = afterOPM->prevScoreDel[afterOPM->numblinks - 1];
		afterOPM->prevFilled[k] = afterOPM->prevFilled[afterOPM->numblinks - 1];
		//	shrink the sizes of prevScore and prevScoreDel by 1
		afterOPM->prevScore.resize(afterOPM->numblinks - 1);
		afterOPM->prevScoreDel.resize(afterOPM->numblinks - 1);
		afterOPM->prevFilled.resize(afterOPM->numblinks - 1);
		-- afterOPM->numblinks;
	}
	//	this case involves score adjustment


	for(i = 0; i < numbwOPM; ++ i)	{
		OPM* aheadOPM = backwardOPM[i];
		k = crtDel->bLocator[backwardOPMnew[i]];
		for(j = 0; j < crtDel->numflinks; ++ j)	{
			OPM* afterOPM = crtDel->flinks[j];
			//	link these two OPMs
			aheadOPM->flinks.resize(aheadOPM->numflinks + 1);
			aheadOPM->fLocator.resize(aheadOPM->numflinks + 1);
			aheadOPM->flinks[aheadOPM->numflinks] = afterOPM;
			aheadOPM->fLocator[aheadOPM->numflinks] = afterOPM->numblinks;

			afterOPM->blinks.resize(afterOPM->numblinks + 1);
			afterOPM->bLocator.resize(afterOPM->numblinks + 1);
			afterOPM->blinks[afterOPM->numblinks] = aheadOPM;
			afterOPM->bLocator[afterOPM->numblinks] = aheadOPM->numflinks;

			//	update the scores
			afterOPM->prevScore.resize(afterOPM->numblinks + 1);
			afterOPM->prevScoreDel.resize(afterOPM->numblinks + 1);
			afterOPM->prevFilled.resize(afterOPM->numblinks + 1);
			afterOPM->prevScore[afterOPM->numblinks] = OldblinkScores[j];
			afterOPM->prevScore[afterOPM->numblinks] += crtDel->prevScoreDel[k];
			afterOPM->prevScoreDel[afterOPM->numblinks] = OldblinkScoresDel[j];
			afterOPM->prevScoreDel[afterOPM->numblinks] += crtDel->prevScoreDel[k];
			afterOPM->prevFilled[afterOPM->numblinks] = true;

			++ aheadOPM->numflinks;
			++ afterOPM->numblinks;
		}
	}

	//	maintain the linked list
	if(crtDel->prev != NULL && crtDel->next != NULL)	{
		crtDel->prev->next = crtDel->next;
		crtDel->next->prev = crtDel->prev;
	}	else if(crtDel->prev == NULL && crtDel->next == NULL)	{
		ActiveOPMhead = NULL;
	}	else if(crtDel->prev == NULL && crtDel->next != NULL)	{
		ActiveOPMhead = crtDel->next;
		crtDel->next->prev = NULL;
	}	else if(crtDel->prev != NULL && crtDel->next == NULL)	{
		crtDel->prev->next = NULL;
		ActiveOPMtail = crtDel->prev;
	}

	delete [] OldblinkScores;
	delete [] OldblinkScoresDel;

	return;
}

void StructureAlignment::AlignRNAPairs(void)	{
	register int i, j, k, l;

	//	Filling the table with DP
	for(i = 0; i < S.RNAnumPairs; ++ i)	{
		for(j = 0; j < T.RNAnumPairs; ++ j)	{

			//cout << "****************:	" << i << "	" << j << endl;

			//	check whether there are OPMs enclosed by pi and pj
			OPM **downOPMList = new OPM* [NUMOPM];
			int numdownOPM = 0;
			OPM **downOPMListConf = new OPM* [NUMOPM];
			int numdownOPMConf = 0;
			OPM *current = ActiveOPMhead;
			//	go over the entire OPM list, using O(Z) time
			while(current != NULL)	{
				//	if the OPM is enclosed by pi and pj
				//	allowing conflict with base pairs i and j
				if(S.RNApairs[i][0] <= S.RNApairs[current->bpS][0] &&
					S.RNApairs[i][1] >= S.RNApairs[current->bpS][1] &&
					T.RNApairs[j][0] <= T.RNApairs[current->bpT][0] &&
					T.RNApairs[j][1] >= T.RNApairs[current->bpT][1])	{
					//	add the OPM to the list of downOPMs
					downOPMListConf[numdownOPMConf ++] = current;
				}
				current = current->next;
			}

			//cout << "NumdownOPMs:	" << numdownOPMConf << endl;
			//for(k = 0; k < numdownOPMConf; ++ k)	{
			//	cout << downOPMListConf[k]->bpS << "	" << downOPMListConf[k]->bpT << endl;
			//}

			bool isOPM;
			int OPTChainScore = -MAX;
			if(numdownOPMConf > 0)	{
				FillOPMSeqScore(i, j, numdownOPMConf, downOPMListConf);
				OPTChainScore = CalOPMMatching(isOPM, i, j, numdownOPMConf, downOPMListConf, Matched[i][j]);

				if(	isOPM && Matched[i][j].num == 1 &&
					S.RNApairs[Matched[i][j].coordinates[0]][0] - 1 == S.RNApairs[i][0] &&
					S.RNApairs[Matched[i][j].coordinates[0]][1] + 1 == S.RNApairs[i][1] &&
					T.RNApairs[Matched[i][j].coordinates[1]][0] - 1 == T.RNApairs[j][0] &&
					T.RNApairs[Matched[i][j].coordinates[1]][1] + 1 == T.RNApairs[j][1])	{
					ContStacking[i][j] = ContStacking[Matched[i][j].coordinates[0]][Matched[i][j].coordinates[1]] + 1;
				}

				if(isOPM)	{
					Table[i][j] = OPTChainScore;
				}	else	{
					Table[i][j] = -MAX;
				}

			}

			int minHL = (S.RNApairs[i][1] - S.RNApairs[i][0]) < (T.RNApairs[j][1] - T.RNApairs[j][0]) ?
				(S.RNApairs[i][1] - S.RNApairs[i][0] - 1) : (T.RNApairs[j][1] - T.RNApairs[j][0] - 1);
			int lenDiff = abs((S.RNApairs[i][1] - S.RNApairs[i][0]) - (T.RNApairs[j][1] - T.RNApairs[j][0]));
			int pairScore = Score.W1 * Score.Sbp[Score.bpHash((int) S.RNAseq[S.RNApairs[i][0]], (int) S.RNAseq[S.RNApairs[i][1]])][Score.bpHash((int) T.RNAseq[T.RNApairs[j][0]], (int) T.RNAseq[T.RNApairs[j][1]])];

			int maxSeqScore = Score.W3 * (minHL * Score.Snc[0][0] - lenDiff * Score.GAPET) + pairScore;
			maxSeqScore -= (int) (Score.W1 * Score.BPDelete * (S.DelHairpin[i] + T.DelHairpin[j]) / 100);

			if(numdownOPMConf <= 0 || OPTChainScore < maxSeqScore)	{
				//	compute hairpin loop score
				int hairpinScore = pairScore;
				//	compute the score for sequence alignment
				string sA = S.RNAseq.substr(S.RNApairs[i][0] + 1, S.RNApairs[i][1] - S.RNApairs[i][0] - 1);
				string sB = T.RNAseq.substr(T.RNApairs[j][0] + 1, T.RNApairs[j][1] - T.RNApairs[j][0] - 1);
				SequenceAlignment hairpin(false, sA, sB, Score);
				int alignScore = Score.W3 * hairpin.ComputeScore();
				hairpinScore += alignScore;
				//cout << "align Score:	" << alignScore << endl;
				hairpinScore -= (int) Score.W1 * Score.BPDelete * ((S.DelHairpin[i] + T.DelHairpin[j]) / 100);
				//cout << "hairpin Score:	" << hairpinScore << endl;

				//	update score
				if(hairpinScore > OPTChainScore)	{
					isOPM = true;
					Table[i][j] = hairpinScore;
				}
			}

			//cout << "Score:	" << Table[i][j] << endl;

			if(isOPM)	{
				//	determine OPM deletion here
				for(k = numdownOPMConf - 1; k >= 0; -- k)	{
					int appendScore = ComputeAppendScore(i, j, downOPMListConf[k]->bpS, downOPMListConf[k]->bpT);
					if( i != downOPMListConf[k]->bpS && j != downOPMListConf[k]->bpT &&
						S.DelLeftPair[downOPMListConf[k]->bpS][i] == 0 && S.DelRightPair[downOPMListConf[k]->bpS][i] == 0 &&
						T.DelLeftPair[downOPMListConf[k]->bpT][j] == 0 && T.DelRightPair[downOPMListConf[k]->bpT][j] == 0 &&
						Table[i][j] > appendScore + Table[downOPMListConf[k]->bpS][downOPMListConf[k]->bpT]
						)	{
						//cout << "deleting OPM:	" << downOPMListConf[k]->bpS << "	" << downOPMListConf[k]->bpT << endl;
						DelOPM(downOPMListConf[k]);
					}
				}
				//cout << "is OPM!!!" << endl;
				OPM *crtMATCH = new OPM;
				AddOPM(crtMATCH, i, j);
			}
			delete [] downOPMList;
			delete [] downOPMListConf;
		}
	}

	//	TraceBack stage
	MPair allmatched;
	allmatched.num = 0;
	allmatched.coordinates = new int [S.RNAnumPairs + T.RNAnumPairs];
	finalScore = TraceBack(allmatched);

	//	Output Alignment
	cout << "Score:	" << finalScore << endl;
	cout << "lengthS:	" << S.RNAseqlength << endl;
	cout << "lengthT:	" << T.RNAseqlength << endl;
	cout << "pairs S:	" << S.RNAnumPairs << endl;
	cout << "pairs T:	" << T.RNAnumPairs << endl;
	cout << "pairs:	" << (int) ((S.RNAnumPairs + T.RNAnumPairs) / 2) << endl;
	cout << "num OPM:	" << MAXNUMOPM << endl;
	cout << "num pair matched:	" << allmatched.num << endl;

	OutputAlignment(allmatched);

	delete [] allmatched.coordinates;

	return;
}

//	add basepair deletion score
void StructureAlignment::FillOPMSeqScore(int m1, int m2, int numdownOPM, OPM** downOPMList)	{

	register int i, j, k;

	//	first resume the sequence alignment for each OPM

	int *enclosed = new int [MAXOPMID + 1];
	for(i = 0; i <= MAXOPMID; ++ i)	{
		enclosed[i] = 0;
	}

	for(i = 0; i < numdownOPM; ++ i)	{
		enclosed[downOPMList[i]->ID] = 1;
	}

	for(i = 0; i < numdownOPM; ++ i)	{

		int n1 = downOPMList[i]->bpS;
		int n2 = downOPMList[i]->bpT;

		OPM* crtOPM = downOPMList[i];

		string seqSLeft = S.RNAseq.substr(S.RNApairs[m1][0], S.RNApairs[n1][0] - S.RNApairs[m1][0]);
		string seqTLeft = T.RNAseq.substr(T.RNApairs[m2][0], T.RNApairs[n2][0] - T.RNApairs[m2][0]);
		string seqSRight = S.RNAseq.substr(S.RNApairs[n1][1] + 1, S.RNApairs[m1][1] - S.RNApairs[n1][1]);
		string seqTRight = T.RNAseq.substr(T.RNApairs[n2][1] + 1, T.RNApairs[m2][1] - T.RNApairs[n2][1]);

		//	compute sequence alignment for the left half
		ReverseString(seqSLeft);
		ReverseString(seqTLeft);
		ResumeSeqAlignment AlignLeft(seqSLeft, seqTLeft, Score,
			crtOPM->LlenSup, crtOPM->LlenSdown, crtOPM->LlenTup, crtOPM->LlenTdown);
		AlignLeft.Extend(crtOPM->LlenSup, crtOPM->LlenSdown, crtOPM->LlenTup, crtOPM->LlenTdown,
			crtOPM->LedgeScoreS, crtOPM->LedgeScoreT, crtOPM->LdelScore, crtOPM->LinsScore);

		//	record necessary score
		if(n1 != m1 && n2 != m2)	{
			crtOPM->leftBoundScore = Score.W3 * AlignLeft.AlignScore(seqSLeft.length() - 1, seqTLeft.length() - 1);
			crtOPM->leftBoundScore -= (int) Score.W1 * Score.BPDelete * ((S.DelLeftPair[n1][m1] + T.DelLeftPair[n2][m2]) / 100);
		}	else	{
			crtOPM->leftBoundScore = -MAX;
		}
		crtOPM->leftBoundScoreConf = Score.W3 * AlignLeft.AlignScore(seqSLeft.length(), seqTLeft.length());
		crtOPM->leftBoundScoreConf -= (int) Score.W1 * Score.BPDelete * ((S.DelLeftPairConf[n1][m1] + T.DelLeftPairConf[n2][m2]) / 100);

		//	compute sequence alignment for the right half

		ResumeSeqAlignment AlignRight(seqSRight, seqTRight, Score,
			crtOPM->RlenSup, crtOPM->RlenSdown, crtOPM->RlenTup, crtOPM->RlenTdown);
		AlignRight.Extend(crtOPM->RlenSup, crtOPM->RlenSdown, crtOPM->RlenTup, crtOPM->RlenTdown,
			crtOPM->RedgeScoreS, crtOPM->RedgeScoreT, crtOPM->RdelScore, crtOPM->RinsScore);

		//	record necessary score
		if(n1 != m1 && n2 != m2)	{
			crtOPM->rightBoundScore = Score.W3 * AlignRight.AlignScore(seqSRight.length() - 1, seqTRight.length() - 1);
			crtOPM->rightBoundScore -= (int) Score.W1 * Score.BPDelete * ((S.DelRightPair[n1][m1] + T.DelRightPair[n2][m2]) / 100);
		}	else	{
			crtOPM->rightBoundScore = -MAX;
		}
		crtOPM->rightBoundScoreConf = Score.W3 * AlignRight.AlignScore(seqSRight.length(), seqTRight.length());
		crtOPM->rightBoundScoreConf -= (int) Score.W1 * Score.BPDelete * ((S.DelRightPairConf[n1][m1] + T.DelRightPairConf[n2][m2]) / 100);

		for(j = 0; j < crtOPM->numflinks; ++ j)	{

			if(enclosed[crtOPM->flinks[j]->ID])	{
				int l1 = S.RNApairs[crtOPM->flinks[j]->bpS][0] - S.RNApairs[n1][1] - 1;
				int l2 = T.RNApairs[crtOPM->flinks[j]->bpT][0] - T.RNApairs[n2][1] - 1;
				int l1Del = S.RNApairs[crtOPM->flinks[j]->bpS][1] - S.RNApairs[n1][1];
				int l2Del = T.RNApairs[crtOPM->flinks[j]->bpT][1] - T.RNApairs[n2][1];

				k = crtOPM->fLocator[j];

				int ks1 = crtOPM->bpS, ks2 = crtOPM->flinks[j]->bpS;
				int kt1 = crtOPM->bpT, kt2 = crtOPM->flinks[j]->bpT;
				if(!crtOPM->flinks[j]->prevFilled[k])	{
					crtOPM->flinks[j]->prevScore[k] = Score.W3 * AlignRight.AlignScore(l1, l2);
					crtOPM->flinks[j]->prevScore[k] -= (int) Score.W1 * ((S.DelPara[ks2][ks1] + T.DelPara[kt2][kt1]) / 100);

					crtOPM->flinks[j]->prevScoreDel[k] = Score.W3 * AlignRight.AlignScore(l1Del, l2Del);
					crtOPM->flinks[j]->prevScoreDel[k] -= (int) Score.W1 * ((S.DelParaDel[ks2][ks1] + T.DelParaDel[kt2][kt1]) / 100);

					crtOPM->flinks[j]->prevFilled[k] = true;
				}
			}

		}
	}

	delete [] enclosed;
	return;
}


//	add basepair deletion score
void StructureAlignment::FillOPMSeqScoreLast(int numdownOPM, OPM** downOPMList)	{

	register int i, j, k;

	//	first resume the sequence alignment for each OPM

	int *enclosed = new int [MAXOPMID + 1];
	for(i = 0; i <= MAXOPMID; ++ i)	{
		enclosed[i] = 0;
	}

	for(i = 0; i < numdownOPM; ++ i)	{
		enclosed[downOPMList[i]->ID] = 1;
	}

	for(i = 0; i < numdownOPM; ++ i)	{

		int n1 = downOPMList[i]->bpS;
		int n2 = downOPMList[i]->bpT;
		OPM* crtOPM = downOPMList[i];

		string seqSLeft = S.RNAseq.substr(0, S.RNApairs[n1][0]);
		string seqTLeft = T.RNAseq.substr(0, T.RNApairs[n2][0]);
		string seqSRight = S.RNAseq.substr(S.RNApairs[n1][1] + 1, S.RNAseqlength - S.RNApairs[n1][1] - 1);
		string seqTRight = T.RNAseq.substr(T.RNApairs[n2][1] + 1, T.RNAseqlength - T.RNApairs[n2][1] - 1);

		//	compute sequence alignment for the left half
		ReverseString(seqSLeft);
		ReverseString(seqTLeft);
		ResumeSeqAlignment AlignLeft(seqSLeft, seqTLeft, Score,
			crtOPM->LlenSup, crtOPM->LlenSdown, crtOPM->LlenTup, crtOPM->LlenTdown);
		AlignLeft.Extend(crtOPM->LlenSup, crtOPM->LlenSdown, crtOPM->LlenTup, crtOPM->LlenTdown,
			crtOPM->LedgeScoreS, crtOPM->LedgeScoreT, crtOPM->LdelScore, crtOPM->LinsScore);


		//	record necessary score
		crtOPM->leftBoundScore = Score.W3 * AlignLeft.AlignScore(seqSLeft.length(), seqTLeft.length());
		crtOPM->leftBoundScore -= (int) Score.W1 * Score.BPDelete * ((S.DelLeftBound[n1] + T.DelLeftBound[n2]) / 100);
		crtOPM->leftBoundScoreConf = -MAX;

		//	compute sequence alignment for the right half

		ResumeSeqAlignment AlignRight(seqSRight, seqTRight, Score,
			crtOPM->RlenSup, crtOPM->RlenSdown, crtOPM->RlenTup, crtOPM->RlenTdown);
		AlignRight.Extend(crtOPM->RlenSup, crtOPM->RlenSdown, crtOPM->RlenTup, crtOPM->RlenTdown,
			crtOPM->RedgeScoreS, crtOPM->RedgeScoreT, crtOPM->RdelScore, crtOPM->RinsScore);

		//	record necessary score

		crtOPM->rightBoundScore = AlignRight.AlignScore(seqSRight.length(), seqTRight.length());
		crtOPM->rightBoundScore -= (int) Score.W1 * Score.BPDelete * ((S.DelRightBound[n1] + T.DelRightBound[n2]) / 100);
		crtOPM->rightBoundScoreConf = -MAX;
		for(j = 0; j < crtOPM->numflinks; ++ j)	{

			if(enclosed[crtOPM->flinks[j]->ID])	{
				int l1 = S.RNApairs[crtOPM->flinks[j]->bpS][0] - S.RNApairs[n1][1] - 1;
				int l2 = T.RNApairs[crtOPM->flinks[j]->bpT][0] - T.RNApairs[n2][1] - 1;
				int l1Del = S.RNApairs[crtOPM->flinks[j]->bpS][1] - S.RNApairs[n1][1];
				int l2Del = T.RNApairs[crtOPM->flinks[j]->bpT][1] - T.RNApairs[n2][1];

				k = crtOPM->fLocator[j];

				int ks1 = crtOPM->bpS, ks2 = crtOPM->flinks[j]->bpS;
				int kt1 = crtOPM->bpT, kt2 = crtOPM->flinks[j]->bpT;
				if(!crtOPM->flinks[j]->prevFilled[k])	{
					crtOPM->flinks[j]->prevScore[k] = Score.W3 * AlignRight.AlignScore(l1, l2);
					crtOPM->flinks[j]->prevScore[k] -= (int) Score.W1 * ((S.DelPara[ks2][ks1] + T.DelPara[kt2][kt1]) / 100);

					crtOPM->flinks[j]->prevScoreDel[k] = Score.W3 * AlignRight.AlignScore(l1Del, l2Del);
					crtOPM->flinks[j]->prevScoreDel[k] -= (int) Score.W1 * ((S.DelParaDel[ks2][ks1] + T.DelParaDel[kt2][kt1]) / 100);

					crtOPM->flinks[j]->prevFilled[k] = true;
				}
			}
		}
	}

	delete [] enclosed;
	return;
}



int StructureAlignment::CalOPMMatching(bool &isOPM, int m1, int m2, int numdownOPM, OPM** downOPMList, MPair &chain)	{

	//	*assume there is no OPM deletions on-the-fly*

	//	m1, m2: the two base pairs that encloses the OPMs, using the base pairing sorting order
	//	numdownOPM: number of OPMs enclosed by m1 and m2
	//	downOPMList: list of OPMs, indicated by the pointers, each OPM has a unique ID
	//	score: the maximum score, used for pass results
	//	conflict: indicate whether the maximum score involve the matching of
	//		OPMs that contains m1 or m2, used for check triangular inequality
	//	chain: the chain of OPMs that have been matched to result in the maximum score

	//	boundary case, when there is no OPMs enclosed
	if(numdownOPM == 0)	{
		//	a consenus case of hairpin loop, assume the enclosing pair matches
		isOPM = true;
		return -MAX;
	}

	register int i, j, k;
	//	the one dimensional array storing the optimal score up to the current OPM
	//	and the link tells where the score comes from (for traceback)
	int *OPTscore = new int [numdownOPM], *POSTscore = new int [numdownOPM];
	int *OPTscoreConf = new int [numdownOPM], *POSTscoreConf = new int [numdownOPM];
	int	*prevLink = new int [numdownOPM], *matchedOPM = new int [numdownOPM];

	//	create an array for fast determination of whether the OPM is enclosed by m1 and m2
	//	add hash the score array using the OPM ID as key
	int *enclosed = new int [MAXOPMID];
	for(i = 0; i < MAXOPMID; ++ i)	{
		enclosed[i] = -1;
	}

	for(i = 0; i < numdownOPM; ++ i)	{
		enclosed[downOPMList[i]->ID] = i + 1;
		OPTscore[i] = POSTscore[i] = OPTscoreConf[i] = POSTscoreConf[i] = 0;
		prevLink[i] = -1;
		matchedOPM[i] = 1;
	}


	//	compute the corresponding forward (score between the leftmost index
	//	and all potential base pair ending indeces to current) OPTscore

	for(i = 0; i < numdownOPM; ++ i)	{

		//	initilize the link to the enclosing base pair

		int n1 = downOPMList[i]->bpS;
		int n2 = downOPMList[i]->bpT;
		OPM* crtOPM = downOPMList[i];

		OPTscore[i] = crtOPM->leftBoundScore;
		POSTscore[i] = crtOPM->rightBoundScore;
		OPTscoreConf[i] = crtOPM->leftBoundScoreConf;
		POSTscoreConf[i] = crtOPM->rightBoundScoreConf;

		//	add the score for matching the current OPM
		OPTscore[i] += Table[n1][n2];
		OPTscoreConf[i] += Table[n1][n2];
		for(j = 0; j < crtOPM->numblinks; ++ j)	{

			if(enclosed[crtOPM->blinks[j]->ID] > 0 &&
				OPTscore[enclosed[crtOPM->blinks[j]->ID] - 1] + crtOPM->prevScore[j] + Table[n1][n2] > OPTscore[i])	{
				OPTscore[i] = OPTscore[enclosed[crtOPM->blinks[j]->ID] - 1] + crtOPM->prevScore[j] + Table[n1][n2];
				prevLink[i] = enclosed[crtOPM->blinks[j]->ID] - 1;
				matchedOPM[i] = 1;
			}

			if(enclosed[crtOPM->blinks[j]->ID] > 0 &&
				OPTscore[enclosed[crtOPM->blinks[j]->ID] - 1] + crtOPM->prevScoreDel[j] > OPTscore[i])	{
				OPTscore[i] = OPTscore[enclosed[crtOPM->blinks[j]->ID] - 1] + crtOPM->prevScoreDel[j];
				prevLink[i] = enclosed[crtOPM->blinks[j]->ID] - 1;
				matchedOPM[i] = 0;
			}

			if(enclosed[crtOPM->blinks[j]->ID] > 0 &&
				OPTscoreConf[enclosed[crtOPM->blinks[j]->ID] - 1] + crtOPM->prevScore[j] + Table[n1][n2] > OPTscoreConf[i])	{
				OPTscoreConf[i] = OPTscoreConf[enclosed[crtOPM->blinks[j]->ID] - 1] + crtOPM->prevScore[j] + Table[n1][n2];
			}

			if(enclosed[crtOPM->blinks[j]->ID] > 0 &&
				OPTscoreConf[enclosed[crtOPM->blinks[j]->ID] - 1] + crtOPM->prevScoreDel[j] > OPTscoreConf[i])	{
				OPTscoreConf[i] = OPTscoreConf[enclosed[crtOPM->blinks[j]->ID] - 1] + crtOPM->prevScoreDel[j];
			}

		}

	}
	//	find the optimal score
	int maxScore = -MAX, maxScoreConf = -MAX;
	int maxOPM = 0;
	for(i = 0; i < numdownOPM; ++ i)	{
		OPTscore[i] += POSTscore[i];
		OPTscoreConf[i] += POSTscoreConf[i];
		if(matchedOPM[i] == 1)	{
			//	add stacking bonus
			if(	S.RNApairs[downOPMList[i]->bpS][0] - 1 == S.RNApairs[m1][0] &&
				S.RNApairs[downOPMList[i]->bpS][1] + 1 == S.RNApairs[m1][1] &&
				T.RNApairs[downOPMList[i]->bpT][0] - 1 == T.RNApairs[m2][0] &&
				T.RNApairs[downOPMList[i]->bpT][1] + 1 == T.RNApairs[m2][1])	{
				OPTscore[i] += Score.W1 * (ContStacking[downOPMList[i]->bpS][downOPMList[i]->bpT] + 1) * Score.BPStack;
				//OPTscore[i] += Score.W1 * Score.BPStack;
			}
			if(OPTscore[i] > maxScore)	{
				maxScore = OPTscore[i];
				maxOPM = i;
			}
			if(OPTscoreConf[i] > maxScoreConf)	{
				maxScoreConf = OPTscoreConf[i];
			}
		}
	}

	//	compute the pairing score for match m1 and m2
	int pairScore = Score.W1 * Score.Sbp[Score.bpHash((int) S.RNAseq[S.RNApairs[m1][0]], (int) S.RNAseq[S.RNApairs[m1][1]])][Score.bpHash((int) T.RNAseq[T.RNApairs[m2][0]], (int) T.RNAseq[T.RNApairs[m2][1]])];
	//	implicitly times the probability by 100
	//pairScore += (int) (Score.W1 * (S.RNApairs[m1][2] + T.RNApairs[m2][2]));

	//	add the score for matching m1 and m2
	maxScore += pairScore;

	//cout << "Chain Scores:	" << maxScore << "	" << maxScoreConf << endl;

	if(maxScore > maxScoreConf)	{
		isOPM = true;
		//	record the matching pairs
		while(prevLink[maxOPM] != -1 && matchedOPM[maxOPM] == 1)	{
			//	if there are matched OPMs then record the OPM
			chain.coordinates[2 * chain.num] = downOPMList[maxOPM]->bpS;
			chain.coordinates[2 * chain.num + 1] = downOPMList[maxOPM]->bpT;
			++ chain.num;
			maxOPM = prevLink[maxOPM];
		}
		//	record the first matching pair
		if(matchedOPM[maxOPM] == 1)	{
			chain.coordinates[2 * chain.num] = downOPMList[maxOPM]->bpS;
			chain.coordinates[2 * chain.num + 1] = downOPMList[maxOPM]->bpT;
			++ chain.num;
		}
	}	else	{
		isOPM = false;
	}

	delete [] enclosed;
	delete [] OPTscore;
	delete [] OPTscoreConf;
	delete [] POSTscore;
	delete [] POSTscoreConf;
	delete [] prevLink;
	delete [] matchedOPM;

	return maxScore > maxScoreConf ? maxScore : maxScoreConf;

}



//	This function is used for traceback
int StructureAlignment::TraceBack(MPair &allmatched)	{
	register int i, j;
	//	sample matched base pairs
	MPair lastmatched;
	lastmatched.num = 0;
	lastmatched.coordinates = new int [S.RNAnumPairs + T.RNAnumPairs];
	int lastnumdownOPM = 0;
	OPM **lastdownOPMList = new OPM*[S.RNAnumPairs * T.RNAnumPairs];
	//	check whether there are OPMs enclosed by pi and pj
	OPM *current = ActiveOPMhead;
	//	go over the entire OPM list, using O(Z) time
	while(current != NULL)	{
		//	add the OPM to the list of downOPMs
		lastdownOPMList[lastnumdownOPM ++] = current;
		current = current->next;
	}

	FillOPMSeqScoreLast(lastnumdownOPM, lastdownOPMList);
	int optScore = FindLocalMatching(lastnumdownOPM, lastdownOPMList, lastmatched);

	//	recursively samples all the matched pairs
	RetrieveMatchedPairs(lastmatched, allmatched);
	delete [] lastdownOPMList;
	delete [] lastmatched.coordinates;
	return optScore;
}

//	Recursively retrieve the matched base pairs, return the last pointer
//	(empty, does not contain information) of the chain
void StructureAlignment::RetrieveMatchedPairs(MPair lastmatched, MPair &allmatched)	{
	register int i, j;
	for(i = 0; i < lastmatched.num; ++ i)	{
		//	add the base pair
		allmatched.coordinates[2 * allmatched.num] = lastmatched.coordinates[2 * i];
		allmatched.coordinates[2 * allmatched.num + 1] = lastmatched.coordinates[2 * i + 1];
		++ allmatched.num;
		//	recursive call adding inner base pairs
		RetrieveMatchedPairs(Matched[lastmatched.coordinates[2 * i]][lastmatched.coordinates[2 * i + 1]],
			allmatched);
	}
	return;
}


//	This function is similar to ChainScorePair, the difference is that in this function,
//	initial and ending deletion penalty is not counted, such that all pairs inside are
//	treated local
int StructureAlignment::FindLocalMatching(int lastnumdownOPM, OPM** lastdownOPMList, MPair &lastmatch)	{

	//	boundary case, when there is no OPMs enclosed
	if(lastnumdownOPM == 0)	{
		return -MAX;
	}

	register int i, j, k;

	//	the one dimensional array storing the optimal score up to the current OPM
	//	and the link tells where the score comes from (for traceback)
	int *OPTscore = new int[lastnumdownOPM], *POSTscore = new int[lastnumdownOPM];
	int	*prevLink = new int[lastnumdownOPM], *matchedOPM = new int[lastnumdownOPM];

	//	create an array for fast determination of whether the OPM is enclosed by m1 and m2
	//	add hash the score array using the OPM ID as key
	int *enclosed = new int[MAXOPMID];
	for(i = 0; i < lastnumdownOPM; ++ i)	{
		enclosed[lastdownOPMList[i]->ID] = i + 1;
		OPTscore[i] = POSTscore[i] = 0;
		matchedOPM[i] = 1;
		prevLink[i] = -1;
	}

	//	compute the corresponding forward (score between the leftmost index
	//	and all potential base pair ending indeces to current) OPTscore
	for(i = 0; i < lastnumdownOPM; ++ i)	{
		//	initilize the link to the enclosing base pair

		int n1 = lastdownOPMList[i]->bpS;
		int n2 = lastdownOPMList[i]->bpT;
		OPM* crtOPM = lastdownOPMList[i];

		OPTscore[i] = crtOPM->leftBoundScore;
		if(Score.Local && OPTscore[i] < 0)	{
			OPTscore[i] = 0;
		}

		POSTscore[i] = crtOPM->rightBoundScore;
		if(Score.Local && POSTscore[i] < 0)	{
			POSTscore[i] = 0;
		}

		OPTscore[i] += Table[n1][n2];
		for(j = 0; j < crtOPM->numblinks; ++ j)	{

			//	if the current OPM is taken as a match
			if(enclosed[crtOPM->blinks[j]->ID] > 0 &&
				OPTscore[enclosed[crtOPM->blinks[j]->ID] - 1] + crtOPM->prevScore[j] + Table[n1][n2] > OPTscore[i])	{
				OPTscore[i] = OPTscore[enclosed[crtOPM->blinks[j]->ID] - 1] + crtOPM->prevScore[j] + Table[n1][n2];
				prevLink[i] = enclosed[crtOPM->blinks[j]->ID] - 1;
				matchedOPM[i] = 1;
			}

			//	if the current OPM is deleted
			if(enclosed[crtOPM->blinks[j]->ID] > 0 &&
				OPTscore[enclosed[crtOPM->blinks[j]->ID] - 1] + crtOPM->prevScoreDel[j] > OPTscore[i])	{
				OPTscore[i] = OPTscore[enclosed[crtOPM->blinks[j]->ID] - 1] + crtOPM->prevScoreDel[j];
				prevLink[i] = enclosed[crtOPM->blinks[j]->ID] - 1;
				matchedOPM[i] = 0;
			}
		}
	}

	//	find the optimal score
	long int maxScore = -MAX;
	int maxOPM = 0;
	for(i = 0; i < lastnumdownOPM; ++ i)	{
		OPTscore[i] += POSTscore[i];
		if(matchedOPM[i] == 1)	{
			if(OPTscore[i] > maxScore)	{
				maxScore = OPTscore[i];
				maxOPM = i;
			}
		}
	}

	//	record the optimal matching chain
	while(prevLink[maxOPM] != -1 && matchedOPM[maxOPM] == 1)	{
		//	if there are matched OPMs then record the OPM
		lastmatch.coordinates[2 * lastmatch.num] = lastdownOPMList[maxOPM]->bpS;
		lastmatch.coordinates[2 * lastmatch.num + 1] = lastdownOPMList[maxOPM]->bpT;
		++ lastmatch.num;
		maxOPM = prevLink[maxOPM];
	}
	//	record the first matching pair
	if(matchedOPM[maxOPM] == 1)	{
		lastmatch.coordinates[2 * lastmatch.num] = lastdownOPMList[maxOPM]->bpS;
		lastmatch.coordinates[2 * lastmatch.num + 1] = lastdownOPMList[maxOPM]->bpT;
		++ lastmatch.num;
	}

	delete []enclosed;
	delete []OPTscore;
	delete []POSTscore;
	delete []prevLink;
	delete []matchedOPM;

	return maxScore;

}

//	Output alignment
//	The function takes all matched base pairs as input, and produce alignment output

void StructureAlignment::OutputAlignment(MPair allmatched)	{
	//	gets the locations of the matched pairs
	register int i, j;
	int *locS = new int [2 * allmatched.num];
	int *locT = new int [2 * allmatched.num];
	char *strS = new char [S.RNAseqlength];
	char *strT = new char [T.RNAseqlength];
	j = 0;
	for	(i = 0; i < allmatched.num; ++ i)	{

		locS[j] = S.RNApairs[allmatched.coordinates[2 * i]][0];
		locS[j + 1] = S.RNApairs[allmatched.coordinates[2 * i]][1];
		strS[S.RNApairs[allmatched.coordinates[2 * i]][0]] = '(';
		strS[S.RNApairs[allmatched.coordinates[2 * i]][1]] = ')';

		locT[j] = T.RNApairs[allmatched.coordinates[2 * i + 1]][0];
		locT[j + 1] = T.RNApairs[allmatched.coordinates[2 * i + 1]][1];
		strT[T.RNApairs[allmatched.coordinates[2 * i + 1]][0]] = '(';
		strT[T.RNApairs[allmatched.coordinates[2 * i + 1]][1]] = ')';

		j += 2;
	}

	//	sort the locations
	qsort(locS, 2 * allmatched.num, sizeof(int), compare);
	qsort(locT, 2 * allmatched.num, sizeof(int), compare);

	string alignmentS, alignmentT, alignmentSym, structureS, structureT;

	//	adding the left flanking sequence alignment
	if(locS[0] > 0 && locT[0] > 0)	{
		string lseqA = S.RNAseq.substr(0, locS[0]);
		string lseqB = T.RNAseq.substr(0, locT[0]);
		SequenceAlignment redoalign(false, lseqA, lseqB, Score);
		redoalign.ALIGN();
		string lalnA, lalnB, lsymbol;
		redoalign.TraceBack(lalnA, lalnB, lsymbol);
		alignmentS += lalnA;
		alignmentT += lalnB;
		alignmentSym += lsymbol;
		string nonstructure(lalnA.length(), '.');
		structureS += nonstructure;
		structureT += nonstructure;
	}	else if(locS[0] > 0 && locT[0] == 0)	{
		for(j = 0; j < locS[0]; ++ j)	{
			alignmentS += int2char((int) S.RNAseq[j]);
		}
		string lseqB(locS[0], '-');
		string emptystr(locS[0], ' ');
		string nonstructure(locS[0], '.');
		alignmentT += lseqB;
		alignmentSym += emptystr;
		structureS += nonstructure;
		structureT += nonstructure;
	}	else if(locS[0] == 0 && locT[0] > 0)	{
		for(j = 0; j < locT[0]; ++ j)	{
			alignmentT += int2char((int) T.RNAseq[j]);
		}
		string lseqA(locT[0], '-');
		string emptystr(locT[0], ' ');
		string nonstructure(locT[0], '.');
		alignmentS += lseqA;
		alignmentSym += emptystr;
		structureS += nonstructure;
		structureT += nonstructure;
	}

	//	adding the alignment

	for	(i = 0; i < 2 * allmatched.num - 1; ++ i)	{

		alignmentS += int2char((int) S.RNAseq[locS[i]]);
		alignmentT += int2char((int) T.RNAseq[locT[i]]);
		alignmentSym += S.RNAseq[locS[i]] == T.RNAseq[locT[i]] ? '*' : '+';
		structureS += strS[locS[i]];
		structureT += strT[locT[i]];
		//	consecutive pairing
		if	(locS[i + 1] - locS[i] == 1 && locT[i + 1] - locT[i] == 1)	{
			;	// doing nothing
		}	else if	(locS[i + 1] - locS[i] == 1)	{
			string gap(locT[i + 1] - locT[i] - 1, '-');
			alignmentS += gap;
			for(j = locT[i] + 1; j <= locT[i + 1] - 1; ++ j)	{
				alignmentT += int2char((int) T.RNAseq[j]);
			}
			string emptystr(locT[i + 1] - locT[i] - 1, ' ');
			alignmentSym += emptystr;
			string nonstructure(locT[i + 1] - locT[i] - 1, '.');
			structureS += nonstructure;
			structureT += nonstructure;
		}	else if	(locT[i + 1] - locT[i] == 1)	{
			string gap(locS[i + 1] - locS[i] - 1, '-');
			for(j = locS[i] + 1; j <= locS[i + 1] - 1; ++ j)	{
				alignmentS += int2char((int) S.RNAseq[j]);
			}
			alignmentT += gap;
			string emptystr(locS[i + 1] - locS[i] - 1, ' ');
			alignmentSym += emptystr;
			string nonstructure(locS[i + 1] - locS[i] - 1, '.');
			structureS += nonstructure;
			structureT += nonstructure;
		}	else if	(locS[i + 1] - locS[i] > 1 && locT[i + 1] - locT[i] > 1)	{
			//	redo the alignment, call llmax
			string lseqA = S.RNAseq.substr(locS[i] + 1, locS[i + 1] - locS[i] - 1);
			string lseqB = T.RNAseq.substr(locT[i] + 1, locT[i + 1] - locT[i] - 1);
			SequenceAlignment redoalign(false, lseqA, lseqB, Score);
			redoalign.ALIGN();
			string lalnA, lalnB, lsymbol;
			redoalign.TraceBack(lalnA, lalnB, lsymbol);
			alignmentS += lalnA;
			alignmentT += lalnB;
			alignmentSym += lsymbol;
			string nonstructure(lalnA.length(), '.');
			structureS += nonstructure;
			structureT += nonstructure;
		}
	}
	alignmentS += int2char((int) S.RNAseq[locS[i]]);
	alignmentT += int2char((int) T.RNAseq[locT[i]]);
	alignmentSym += S.RNAseq[locS[i]] == T.RNAseq[locT[i]] ? '*' : '+';;
	structureS += strS[locS[i]];
	structureT += strT[locT[i]];

	//	adding the right flanking sequence alignment
	if(locS[i] < S.RNAseqlength - 1 && locT[i] < T.RNAseqlength - 1)	{
		string lseqA = S.RNAseq.substr(locS[i] + 1, S.RNAseqlength - locS[i] - 1);
		string lseqB = T.RNAseq.substr(locT[i] + 1, T.RNAseqlength - locT[i] - 1);
		SequenceAlignment redoalign(false, lseqA, lseqB, Score);
		redoalign.ALIGN();
		string lalnA, lalnB, lsymbol;
		redoalign.TraceBack(lalnA, lalnB, lsymbol);
		alignmentS += lalnA;
		alignmentT += lalnB;
		alignmentSym += lsymbol;
		string nonstructure(lalnA.length(), '.');
		structureS += nonstructure;
		structureT += nonstructure;
	}	else if(locS[i] < S.RNAseqlength - 1 && locT[i] == T.RNAseqlength - 1)	{
		for(j = locS[i] + 1; j < S.RNAseqlength; ++ j)	{
			alignmentS += int2char((int) S.RNAseq[j]);
		}
		string lseqB(S.RNAseqlength - locS[i] - 1, '-');
		string emptystr(S.RNAseqlength - locS[i] - 1, ' ');
		string nonstructure(S.RNAseqlength - locS[i] - 1, '.');
		alignmentT += lseqB;
		alignmentSym += emptystr;
		structureS += nonstructure;
		structureT += nonstructure;
	}	else if(locS[i] == S.RNAseqlength - 1 && locT[i] < T.RNAseqlength - 1)	{
		for(j = locT[i] + 1; j < T.RNAseqlength; ++ j)	{
			alignmentT += int2char((int) T.RNAseq[j]);
		}
		string lseqA(T.RNAseqlength - locT[i] - 1, '-');
		string emptystr(T.RNAseqlength - locT[i] - 1, ' ');
		string nonstructure(T.RNAseqlength - locT[i] - 1, '.');
		alignmentS += lseqA;
		alignmentSym += emptystr;
		structureS += nonstructure;
		structureT += nonstructure;
	}

	//	formatting output

	FormatOutput(finalScore, S.RNAheader, T.RNAheader, structureS, structureT,
		alignmentS, alignmentT, alignmentSym);
	delete [] locS, delete [] locT;
	delete [] strS, delete [] strT;
	return;
}

void StructureAlignment::FormatOutput(int finalScore, string RNAheaderS, string RNAheaderT,
	string structureS, string structureT, string alignmentS, string alignmentT, string alignmentSym)	{
	register int i;
	int alnlength = 3000;
	cout << endl;
	cout << "Score:	" << finalScore << endl;
	cout << endl;
	cout << "Alignment:	" << endl << endl;
	for(i = 0; i < alignmentSym.length(); i += alnlength)	{
		cout << structureS.substr(i, alnlength) << endl;
		cout << alignmentS.substr(i, alnlength) << endl;
		cout << alignmentSym.substr(i, alnlength) << endl;
		cout << alignmentT.substr(i, alnlength) << endl;
		cout << structureT.substr(i, alnlength) << endl;
		cout << endl;
	}
	cout << endl;
	cout<<"working"<<endl;

    ofstream fout;
    fout.open ("output/out.txt");
    fout<<"yes"<<endl;
    fout << "Score:	" << finalScore << endl;
	fout << endl;
	fout << "Alignment:	" << endl << endl;
	for(i = 0; i < alignmentSym.length(); i += alnlength)	{
		fout << structureS.substr(i, alnlength) << endl;
		fout << alignmentS.substr(i, alnlength) << endl;
		fout << alignmentSym.substr(i, alnlength) << endl;
		fout << alignmentT.substr(i, alnlength) << endl;
		fout << structureT.substr(i, alnlength) << endl;
		fout << endl;
	}
	fout << endl;
    fout.close();
}

