#include <string>
#include <iostream>
#include <cstdlib>
#include <algorithm>

#include <stdlib.h>
#include <unistd.h>

#include "./inc/StructureAlignment.h"


using namespace std;

string filenameA, filenameB, matrixname;
int ncMatch = 3, ncMismatch = -4, bpMatch = 10, bpMismatch = 8, strWeight = 20, pseqWeight = 1, seqWeight = 1, 
	gapSt = 10, gapEt = 3, bpStack = 2, bpDelete = 3, local = 1;

void printUsage(void)	{
	cout << "Usage: ERA -i RNA1 -j RNA2 [-m -w -s -g -e -d]" << endl << endl;
	cout << "	-i (mandatory, expecting STRING): specify the first RNA structure to be aligned in Vienna format." << endl;
	cout << "	-j (mandatory, expecting STRING): specify the second RNA structure to be aligned in Vienna format." << endl;
	cout << endl;
	cout << "	-m (optional, expecting STRING): specify the scoring matrix. Default: (10 for match, 8 for mismatch)." << endl;
	cout << "	-w (optional, expecting INT): specify the structure weight. Default: 20." << endl;
	cout << "	-s (optional, expecting INT): specify the sequence weight. Default 1." << endl;
	cout << "	-g (optional, expecting INT): specify the gap open penalty for sequence alignment. Default: 10." << endl;
	cout << "	-e (optional, expecting INT): specify the gap extension penalty for sequence alignment. Default: 3." << endl;
	cout << "	-d (optional, expecting INT): specify the base pair deletion penalty. Default 3." << endl;
	cout << "	-h (optional): print this help" << endl;
	cout << endl;
	cout << "	ERA version 1.0." << endl;
	cout << endl;
	return;
}

void initenv(int argc, char **argv)	{
	//initialize environment variable
	int opt = 0;
	while((opt=getopt(argc, argv, "i:j:p:m:a:b:c:t:u:v:x:y:g:e:d:l:h")) != -1) {
		switch(opt) {
			case 'i': {filenameA = string(optarg); break;}
			case 'j': {filenameB = string(optarg); break;}
			case 'm': {matrixname = string(optarg); break;}
			case 'a': {strWeight = atoi(optarg); break;}
			case 'b': {pseqWeight = atoi(optarg); break;}
			case 'c': {seqWeight = atoi(optarg); break;}
			case 't': {bpStack = atoi(optarg); break;}
			case 'u': {ncMatch = atoi(optarg); break;}
			case 'v': {ncMismatch = atoi(optarg); break;}
			case 'x': {bpMatch = atoi(optarg); break;}
			case 'y': {bpMismatch = atoi(optarg); break;}
			case 'g': {gapSt = atoi(optarg); break;}
			case 'e': {gapEt = atoi(optarg); break;}
			case 'd': {bpDelete = atoi(optarg); break;}
			case 'l': {local = atoi(optarg); break;}
			case 'h': {printUsage(); exit(0);}
			default: {printUsage(); exit(0);}
		}
	}
	if(filenameA.empty() || filenameB.empty()){
		printUsage();
		exit(0);
	}
	return;
}


int main(int argc, char **argv) {
	initenv(argc, argv);
	//srand(time(NULL));
	RNAstructure strA(filenameA, 0);
	RNAstructure strB(filenameB, 0);
	//strA.PrintContent();
	//DEBUGstrB.PrintContent();
	Parameters score;
	//cout << strA.RNAnumPairs << endl;
	if	(matrixname.empty())	{
		//matrixname = "./Matrices/RIBOSUM85_60";
		Parameters noRIBOSUM(ncMatch, ncMismatch, bpMatch, bpMismatch, 
			gapSt, gapEt, bpStack, bpDelete, strWeight, pseqWeight, seqWeight, local);
		score = noRIBOSUM;
	}	else	{
		Parameters withRIBOSUM(matrixname, ncMatch, ncMismatch, gapSt, gapEt, 
			bpStack, bpDelete, strWeight, pseqWeight, seqWeight, local);
		score = withRIBOSUM;
	}
	
	//cout << "Parameters OK!" << endl;
	
	//	check if one of the input is pure sequence
	if(strA.RNAnumPairs > 0 && strB.RNAnumPairs > 0)	{
		//DEBUGcout << "Structure detected, will do alignment!" << endl;
		StructureAlignment alignStructure(strA, strB, score);
		//cout << "Alignment object initiated!" << endl;
		alignStructure.AlignRNAPairs();
		//DEBUGcout << "The Maximum OPM ID:	" << alignStructure.MAXOPMID << endl;
		//DEBUGcout << "Alignment finished!" << endl;
	}	else	{
		cout << "Non-structured RNAs contained in inputs. please check." << endl;
	}
	strA.collectMem();
	strB.collectMem();
	return 0;
	
}
