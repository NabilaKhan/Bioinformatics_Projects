#include <iostream>
#include <string>
#include <cstdlib>
#include <fstream>
#include <vector>
#include <deque>
#include <stack>

#define MAXSEQ 2000

using namespace std;

class RNAstructure {
	friend class StructureAlignment;
	
	public:
	string RNAheader;			//	the annotation of the RNA structure
	string RNAseq;				//	the sequence of the RNA structure
	int **RNApairs;				//	the basepairs in the RNA structure
	int **UpArrayHash;			//	the array that hashes the basepair ID to order
	int *sizeUpArray;			//	the number of basepairs that enclosing each basepair
	int *sizeDownArray;			//	the number of basepairs that enclosed by each basepair
	
	//	The index used is [inside][outside] (in terms of enclosing relationship)
	
	int **DelLeftPair;			//	the number of basepairs deleted by left
	int **DelRightPair;			//	the number of basepairs deleted by right
	int **DelLeftPairConf;		//	the number of basepairs deleted by left conflict
	int **DelRightPairConf;		//	the number of basepairs deleted by right conflict
	int **DelPara;				//	the number of basepairs deleted by parallel pairs
	int **DelParaDel;			//	the number of basepairs deleted by parallel post pairs
	int *DelHairpin;			//	the number of basepairs deleted under hairpin loop
	int *DelLeftBound;			//	the number of basepairs deleted from left boundary
	int *DelRightBound;			//	the number of basepairs deleted from right boundary	
		
	int RNAseqlength;
	int RNAnumPairs;
	
	//	constructor and destructor
	RNAstructure()	{;}
	RNAstructure(string filename);
	RNAstructure(string filename, int cutoff);
	~RNAstructure(void);
	void collectMem(void);
	
	void RNAReadFile(string filename, int cutoff);
	void ReadVienna(string filename);
	void ReadRNAfoldPS(string filename, int cutoff);
	void SortPairs(void);
	void BuildArray(void);
	void PrintContent(void);
	
	bool operator= (RNAstructure R)	{
		this->RNAheader = R.RNAheader;
		this->RNAseq = R.RNAseq;
		this->RNAseqlength = R.RNAseqlength;
		this->RNAnumPairs = R.RNAnumPairs;
		
		register int i, j;
		this->RNApairs = new int* [this->RNAnumPairs];
		this->sizeDownArray = new int[this->RNAnumPairs];
		this->sizeUpArray = new int [this->RNAnumPairs];
		this->UpArrayHash = new int* [this->RNAnumPairs];
		this->DelLeftPair = new int* [this->RNAnumPairs];
		this->DelRightPair = new int* [this->RNAnumPairs];
		this->DelLeftPairConf = new int* [this->RNAnumPairs];
		this->DelRightPairConf = new int* [this->RNAnumPairs];
		this->DelPara = new int* [this->RNAnumPairs];
		this->DelParaDel = new int* [this->RNAnumPairs];
		this->DelHairpin = new int [this->RNAnumPairs];
		this->DelLeftBound = new int [this->RNAnumPairs];
		this->DelRightBound = new int [this->RNAnumPairs];
		
		for(i = 0; i < RNAnumPairs; ++ i)	{
			this->RNApairs[i] = new int [3];
			this->RNApairs[i][0] = R.RNApairs[i][0];
			this->RNApairs[i][1] = R.RNApairs[i][1];
			this->RNApairs[i][2] = R.RNApairs[i][2];
			this->sizeDownArray[i] = R.sizeDownArray[i];
			this->sizeUpArray[i] = R.sizeUpArray[i];
			this->UpArrayHash[i] = new int [this->RNAnumPairs];
			this->DelLeftPair[i] = new int [this->RNAnumPairs];
			this->DelRightPair[i] = new int [this->RNAnumPairs];
			this->DelLeftPairConf[i] = new int [this->RNAnumPairs];
			this->DelRightPairConf[i] = new int [this->RNAnumPairs];
			this->DelPara[i] = new int [this->RNAnumPairs];
			this->DelParaDel[i] = new int [this->RNAnumPairs];
			this->DelHairpin[i] = R.DelHairpin[i];
			this->DelLeftBound[i] = R.DelLeftBound[i];
			this->DelRightBound[i] = R.DelRightBound[i];
			for(j = 0; j < RNAnumPairs; ++ j)	{
				this->UpArrayHash[i][j] = R.UpArrayHash[i][j];
				this->DelLeftPair[i][j] = R.DelLeftPair[i][j];
				this->DelRightPair[i][j] = R.DelRightPair[i][j];
				this->DelLeftPairConf[i][j] = R.DelLeftPairConf[i][j];
				this->DelRightPairConf[i][j] = R.DelRightPairConf[i][j];
				this->DelPara[i][j] = R.DelPara[i][j];
				this->DelParaDel[i][j] = R.DelParaDel[i][j];
			}
		}
	}
	
};


