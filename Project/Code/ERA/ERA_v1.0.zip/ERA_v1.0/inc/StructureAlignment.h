#include <map>
#include "RNAstructure.h"
#include "ResumeSeqAlignment.h"

#define MAX 99999999

using namespace std;

class MPair	{
	public:
	int num;
	int *coordinates;
};

class OPM	{
	public:
	OPM()	{;}
	~OPM()	{;}
	//	the ID that uniquely identifies the OPM, not necessarily consequtive
	//	as some OPMs may be deleted. Must be ordered low to high
	int ID;
	//	the base pairs that form the Optimal Pair Matching, corresponding to the
	//	indeces in RNApairs
	int bpS, bpT;

	//	blinks points to the OPMs that belong to the F set of the current OPM
	int numblinks;
	//map<int, int> blinkHash;
	//	bLocator[i] indicates the location where OPM->blinks[i] stores OPM in OPM->blinks[i]->flinks
	//	in another word, OPM->blinks[i]->flinks[OPM->bLocator[i]] = OPM
	vector<int> bLocator;
	vector<OPM*> blinks;
	//	flinks points to the OPMs that whose F set contains the current OPM
	int numflinks;
	//map<int, int> flinkHash;
	vector<int> fLocator;
	vector<OPM*> flinks;
	
	//	used for record and resume sequence alignment
	
	//	the left part
	int LlenSup, LlenSdown, LlenTup, LlenTdown;
	vector<int> LedgeScoreS;
	vector<int> LedgeScoreT;
	vector<int> LdelScore;
	vector<int> LinsScore;

	
	//	the right part
	int RlenSup, RlenSdown, RlenTup, RlenTdown;
	vector<int> RedgeScoreS;
	vector<int> RedgeScoreT;
	vector<int> RdelScore;
	vector<int> RinsScore;
	
	//	stores the parallel score for post pairs and parallel score for post pairs with conflict
	
	//	note that the post score can only store the scores of its reverse F set
	//	in this case some illy positioned pairs may not be optimally aligned
	//	but we have time complexity of O(Zn^2) and space complexity of max(O(n^2), O(Zl))
	
	//	On the other hand, if we consider true optimality, the post score will store information
	//	regarding every post base pair.
	//	in this case we achieved optimality,
	//	but we have time complexity of O(Z^2n^2) and space complexity of O(Z^2)
	
	//	note that Z is the number of OPMs and can be n^2
	
	vector<int> prevScore;
	vector<int> prevScoreDel;
	vector<bool> prevFilled; 
	
	int leftBoundScore, rightBoundScore, leftBoundScoreConf, rightBoundScoreConf;
	OPM *next, *prev;
};

class StructureAlignment	{
	friend class SequenceAlignment;
	public:
	Parameters Score;
	RNAstructure S;
	RNAstructure T;
	int finalScore;
	int MAXOPMID;
	int NUMOPM;
	int MAXNUMOPM;
	StructureAlignment(RNAstructure s, RNAstructure t, Parameters P);
	~StructureAlignment(void);
	
	void PrintContent(void);
	void AlignRNAPairs(void);
	
	void ReverseString(string &s);
	
	/*
	void TraceBackPair(void);
	void TraceBackStack(void);
	*/
	
	private:
	int **Table;
	int **ContStacking;
	MPair **Matched;
	//	the first and last OPM in the linked list
	OPM *ActiveOPMhead, *ActiveOPMtail;
	
	void CollectOPM(OPM* crt);
	void AddOPM(OPM* crtMATCH, int m1, int m2);
	void DelOPM(OPM* crtDel);
	int ComputeAppendScore(int Sout, int Tout, int Sin, int Tin);
	void FillOPMSeqScore(int m1, int m2, int numdownOPM, OPM** downOPMList);
	void FillOPMSeqScoreLast(int numdownOPM, OPM** downOPMList);
	int CalOPMMatching(bool &isOPM, int m1, int m2, int numdownOPM, OPM** downOPMList, MPair &chain);
	int CalOPMMatchingConf(int m1, int m2, int numdownOPMConf, OPM** downOPMListConf, MPair &chain);
	int TraceBack(MPair &allmatched);	
	void RetrieveMatchedPairs(MPair lastmatched, MPair &allmatched);
	int FindLocalMatching(int lastnumdownOPM, OPM** lastdownOPMList, MPair &lastmatch);
	void OutputAlignment(MPair allmatched);
	void FormatOutput(int finalScore, string RNAheaderS, string RNAheaderT, 
	string structureS, string structureT, string alignmentS, string alignmentT, string alignmentSym);
	
	/*
	int ****LastScore;
	int ****DelScore;
	void ComputeLeftRightSim(int m1, int m2, int **leftScore, int **rightScore);
	void ComputeLastScore(void);
	void ComputeDelScore(void);
	int ChainScorePair(int m1, int m2, MPair &chain);
	int GetChainScorePair(int m1, int m2, int p1, int p2, int &opti, int &optj, bool &ismatch, int **mScore);
	int GetEdgeScorePair(int m1, int m2, int p1, int p2, int &opti, int &optj, int **mScore);
	int CheckScore(MPair allmatched);
	*/
};
