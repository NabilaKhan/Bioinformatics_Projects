#include "SequenceAlignment.h"

using namespace std;

class ResumeSeqAlignment	{
	public:
	Parameters Score;
	string SeqA, SeqB;
	
	ResumeSeqAlignment(string A, string B, Parameters P, int lenSup, int lenSdown, int lenTup, int lenTdown)	{
		SeqA = A;
		SeqB = B;
		Score = P;
		
		int lA = SeqA.length(), lB = SeqB.length();
		isNew = isFull = isRight = isDown = isDiagnoal = false;
		oldlenSup = lenSup;
		oldlenSdown = lenSdown;
		oldlenTup = lenTup;
		oldlenTdown = lenTdown;
		
		//cout << "existing alignments:	" << endl;
		//cout << "lenSup	lenTup	lenSdown	lenTdown" << endl;
		//cout << oldlenSup << "	" << oldlenTup << "	" << oldlenSdown << "	" << oldlenTdown << endl;
		
		register int i;
		
		if (lenSup == 0 && lenTup == 0 && lenSdown == 0 && lenTdown == 0)	{
			//cout << "	NEW" << endl;
			isNew = true;
			CC.resize(SeqB.length() + 1);
			DD.resize(SeqB.length() + 1);
			alnScore.resize(SeqA.length() + 1);
			for(i = 0; i <= SeqA.length(); ++ i)	{
				alnScore[i].resize(SeqB.length() + 1);
			}
		}	else if(lenSup == lenSdown && lenTup == lenTdown && lA + 1 > lenTup && lB + 1 > lenSup)	{
			//cout << "	FULL" << endl;
			isFull = true;
			CC.resize(SeqB.length() + 1);
			DD.resize(SeqB.length() + 1);
			alnScore.resize(lenTup);
			for(i = 0; i < lenTup; ++ i)	{
				alnScore[i].resize(SeqB.length() - lenSup + 2);
			}
			alnScoreBackup.resize(SeqA.length() - lenTup + 2);
			for(i = 0; i <= SeqA.length() - lenTup + 1; ++ i)	{
				alnScoreBackup[i].resize(SeqB.length() + 1);
			}
			
		}	else if(lB + 1 > lenSup)	{
			//cout << "	RIGHT" << endl;
			isRight = true;
			CC.resize(SeqB.length() - lenSup + 2);
			DD.resize(SeqB.length() - lenSup + 2);
			alnScore.resize(SeqA.length() + 1);
			for(i = 0; i <= SeqA.length(); ++ i)	{
				alnScore[i].resize(SeqB.length() - lenSup + 2);
			}	
		}	else if(lA + 1 > lenTdown)	{
			//cout << "	DOWN" << endl;
			isDown = true;
			CC.resize(SeqB.length() + 1);
			DD.resize(SeqB.length() + 1);
			alnScore.resize(SeqA.length() - lenTdown + 2);
			for(i = 0; i <= SeqA.length() - lenTdown + 1; ++ i)	{
				alnScore[i].resize(SeqB.length() + 1);
			}
		}	else if(lB + 1 == lenSup || lA + 1 == lenTdown)	{
			//cout << "	DIAGNOAL" << endl;
			isDiagnoal = true;
			CC.resize(SeqB.length() - lenSdown + 2);
			DD.resize(SeqB.length() - lenSdown + 2);
			alnScore.resize(SeqA.length() - lenTup + 2);
			for(i = 0; i <= SeqA.length() - lenTup + 1; ++ i)	{
				alnScore[i].resize(SeqB.length() - lenSdown + 2);
			}
		}	else	{
			cout << "Unexpected ResumeAlignment call!" << endl;
			exit(0);
		}
		//cout << "Finished ResumeAlignment initialization" << endl;
		return;
		
	}	
	
	~ResumeSeqAlignment()	{return;}
	
	void Extend(int &lenSup, int &lenSdown, int &lenTup, int &lenTdown,
		vector<int>& edgeScoreS, vector<int>& edgeScoreT, vector<int>& delScore, vector<int>& insScore)	{
		if(isNew)	{
			//cout << "calling ExtendNew" << endl;
			ExtendNew(lenSup, lenSdown, lenTup, lenTdown, edgeScoreS, edgeScoreT, delScore, insScore);
		}	else if(isFull)	{
			//cout << "calling ExtendFull" << endl;
			ExtendFull(lenSup, lenSdown, lenTup, lenTdown, edgeScoreS, edgeScoreT, delScore, insScore);
		}	else if(isRight)	{
			//cout << "calling ExtendRight" << endl;
			ExtendRight(lenSup, lenSdown, lenTup, lenTdown, edgeScoreS, edgeScoreT, delScore, insScore);
		}	else if(isDown)	{
			//cout << "calling ExtendDown" << endl;
			ExtendDown(lenSup, lenSdown, lenTup, lenTdown, edgeScoreS, edgeScoreT, delScore, insScore);
		}	else if(isDiagnoal)	{
			//cout << "calling ExtendDiagnoal" << endl;
			ExtendDiagnoal(lenSup, lenSdown, lenTup, lenTdown, edgeScoreS, edgeScoreT, delScore, insScore);
		}	else	{
			cout << "Error in determining extension function to be called!" << endl;
			exit(0);
		}
	}
	
	int AlignScore(int i, int j)	{
		if(isNew)	{
			return alnScore[i][j];
		}	else if(isFull)	{
			if(i < oldlenTup - 1)	{
				//cout << "use alnScore:	" << i << "	" << j - oldlenSup + 1 << endl;
				return alnScore[i][j - oldlenSup + 1];
			}	else	{
				//cout << "use alnScoreBackup" << endl;
				return alnScoreBackup[i - oldlenTdown + 1][j];
			}
		}	else if(isRight)	{
			return alnScore[i][j - oldlenSup + 1];
		}	else if(isDown)	{
			return alnScore[i - oldlenTdown + 1][j];
		}	else if(isDiagnoal)	{
			return alnScore[i - oldlenTup + 1][j - oldlenSdown + 1];
		}	else	{
			cout << "Error in returning alignment score!" << endl;
			exit(0);
		}	
	}
	
	void ExtendNew(int &lenSup, int &lenSdown, int &lenTup, int &lenTdown,
		vector<int>& edgeScoreS, vector<int>& edgeScoreT, vector<int>& delScore, vector<int>& insScore);
	void ExtendFull(int &lenSup, int &lenSdown, int &lenTup, int &lenTdown,
		vector<int>& edgeScoreS, vector<int>& edgeScoreT, vector<int>& delScore, vector<int>& insScore);
	void ExtendRight(int &lenSup, int &lenSdown, int &lenTup, int &lenTdown,
		vector<int>& edgeScoreS, vector<int>& edgeScoreT, vector<int>& delScore, vector<int>& insScore);
	void ExtendDown(int &lenSup, int &lenSdown, int &lenTup, int &lenTdown,
		vector<int>& edgeScoreS, vector<int>& edgeScoreT, vector<int>& delScore, vector<int>& insScore);
	void ExtendDiagnoal(int &lenSup, int &lenSdown, int &lenTup, int &lenTdown,
		vector<int>& edgeScoreS, vector<int>& edgeScoreT, vector<int>& delScore, vector<int>& insScore);
	
	
	private:
	bool isNew;
	bool isFull;
	bool isRight;
	bool isDown;
	bool isDiagnoal;
	int oldlenSup;
	int oldlenSdown;
	int oldlenTup;
	int oldlenTdown;
	vector<int> CC;
	vector<int> DD;
	vector<vector<int> >alnScore;
	vector<vector<int> >alnScoreBackup;
};

