#include <iostream>
#include <fstream>
#include <string.h>

#define MAXLINE 500

using namespace std;

class Parameters	{
	public:
	int Snc[4][4];		// the scores of matching / mismatching nucleotides	
	int Sbp[16][16];	// the scores of matching / mismatching basepairs
	int GAPST;			// sequence gap openning
	int GAPET;			// sequence gap extension
	int BPStack;		// base-pair stacking bonus
	int BPDelete;		// base-pair insertion/deletion penalty
	int W1;				// the weight for the base-pair similarity
	int W2;				// the weight for the sequence similarity in the paired region
	int W3;				// the weight for the sequence similarity in the hairpin loop region
	int Local;			// whether to perform local alignment
	
	Parameters()	{
		return;
	}
	
	Parameters(string RibosumFile, int ncMatch, int ncMismatch, int gapSt, int gapEt,
		int bpStack, int bpDelete, int Weight1, int Weight2, int Weight3, int local){
		register int i, j;
		//	Reads in the file
		ifstream Ribosum(RibosumFile.c_str(), ifstream::in);
		if(!Ribosum.good())	{
			cout << "Scoring matrix missing! Please use -m to specify. Available RIBOSUM matrices are under the 'Matrices' directory." << endl;
			exit(0);
		}
		char *tempStr = new char [MAXLINE];
		//	the nucleotide matching score
		for(i = 0; i < 3; ++ i)	{
			Ribosum.getline(tempStr, MAXLINE);
		}
		for(i = 0; i < 4; ++ i)	{
			Ribosum.getline(tempStr, MAXLINE);
			char *pch = strtok(tempStr, "\t");
			for(j = 0; j <= i; ++ j)	{
				pch = strtok(NULL, "\t");
				float s = atof(pch);
				Snc[i][j] = float2int(s * 10);
				Snc[j][i] = Snc[i][j];
				if(i == j)	{
					Snc[i][j] = ncMatch;
				}	else	{
					Snc[i][j] = Snc[j][i] = ncMismatch;
				}
			}
		}
		//	the base pair matching score
		for(i = 0; i < 3; ++ i)	{
			Ribosum.getline(tempStr, MAXLINE);
		}
		for(i = 0; i < 16; ++ i)	{
			Ribosum.getline(tempStr, MAXLINE);
			char *pch = strtok(tempStr, "\t");
			for(j = 0; j <= i; ++ j)	{
				pch = strtok(NULL, "\t");
				float s = atof(pch);
				Sbp[i][j] = float2int(s * 10);
				Sbp[j][i] = Sbp[i][j];
			}
		}
		delete [] tempStr;
		Ribosum.close();
		GAPST = gapSt;
		GAPET = gapEt;
		BPStack = bpStack;
		BPDelete = bpDelete;
		W1 = Weight1;
		W2 = Weight2;
		W3 = Weight3;
		Local = local;
	}
	
	Parameters(int ncMatch, int ncMismatch, int bpMatch, int bpMismatch, int gapSt, int gapEt, int bpStack, 
		int bpDelete,  int Weight1, int Weight2, int Weight3, int local){
		register int i, j;
		//	filling nucleotide scores
		for(i = 0; i < 4; ++ i)	{
			for(j = 0; j < 4; ++ j)	{
				if(i == j)	{
					Snc[i][j] = ncMatch;
				}	else	{
					Snc[i][j] = ncMismatch;
				}
			}
		}
		//	filling base pair scores
		for(i = 0; i < 16; ++ i)	{
			for(j = 0; j < 16; ++ j)	{
				if(i == j)	{
					Sbp[i][j] = bpMatch;
				}	else	{
					Sbp[i][j] = bpMismatch;
				}
			}
		}
		//	consider the isostericity between canonical base pairs
		
		Sbp[3][6] = Sbp[3][9] = Sbp[3][11] = Sbp[3][12] = Sbp[3][14] = 
		Sbp[6][3] = Sbp[9][3] = Sbp[11][3] = Sbp[12][3] = Sbp[14][3] = bpMatch;
		Sbp[6][9] = Sbp[6][11] = Sbp[6][12] = Sbp[6][14] = 
		Sbp[9][6] = Sbp[11][6] = Sbp[12][6] = Sbp[14][6] = bpMatch;
		Sbp[9][11] = Sbp[9][12] = Sbp[9][14] = Sbp[11][9] = Sbp[12][9] = Sbp[14][9] = bpMatch;
		Sbp[11][12] = Sbp[11][14] = Sbp[12][11] = Sbp[14][11]= bpMatch;
		Sbp[12][14] = Sbp[14][12] = bpMatch;
		
		GAPST = gapSt;
		GAPET = gapEt;
		BPStack = bpStack;
		BPDelete = bpDelete;
		W1 = Weight1;
		W2 = Weight2;
		W3 = Weight3;
		Local = local;
	}
	
	~Parameters(void){
		return;
	}

	
	bool operator= (Parameters P) {
		register int i, j;
		for(i = 0; i < 4; ++ i) {
			for(j = 0; j < 4; ++ j) {
				this->Snc[i][j] = P.Snc[i][j];
			}
		}
		for(i = 0; i < 16; ++ i) {
			for(j = 0; j < 16; ++ j) {
				this->Sbp[i][j] = P.Sbp[i][j];
			}
		}
		
		this->GAPST = P.GAPST;
		this->GAPET = P.GAPET;
		this->BPStack = P.BPStack;
		this->BPDelete = P.BPDelete;
		this->W1 = P.W1;
		this->W2 = P.W2;
		this->W3 = P.W3;
		this->Local = P.Local;
	}
	
	int float2int(float a)	{
		int b = (int) a;
		if(a >= 0.0)	{
			float c = (float) b + 0.5;
			return (a >= c ? b + 1 : b);
		}	else	{
			float c = (float) b - 0.5;
			return (a <= c ? b - 1 : b);
		}	
	}
	
	int ncHash(char s)	{
		//	Based on IPUAC nomenclature
		int r;
		if(s == 'A') {
			return 0;
		}	else if(s == 'C')	{
			return 1;
		}	else if(s == 'G')	{
			return 2;
		}	else if(s == 'U' || s == 'T')	{
			return 3;
		}	else if(s == 'R')	{
			r = ((int) rand()) % 2;
			if(r == 0)	{
				return 0;	//	A
			}	else if(r == 1)	{
				return 2;	//	G
			}
		}	else if(s == 'Y')	{
			r = ((int) rand()) % 2;
			if(r == 0)	{
				return 1;	//	C
			}	else if(r == 1)	{
				return 3;	//	T or U
			}
		}	else if(s == 'S')	{
			r = ((int) rand()) % 2;
			if(r == 0)	{
				return 1;	//	C
			}	else if(r == 1)	{
				return 2;	//	G
			}
		}	else if(s == 'W')	{
			r = ((int) rand()) % 2;
			if(r == 0)	{
				return 0;	//	A
			}	else if(r == 1)	{
				return 3;	//	T or U
			}
		}	else if(s == 'K')	{
			r = ((int) rand()) % 2;
			if(r == 0)	{
				return 2;	//	G
			}	else if(r == 1)	{
				return 3;	//	T or U
			}
		}	else if(s == 'M')	{
			r = ((int) rand()) % 2;
			if(r == 0)	{
				return 0;	//	A
			}	else if(r == 1)	{
				return 1;	//	C
			}
		}	else if(s == 'B')	{
			r = ((int) rand()) % 3;
			if(r == 0)	{
				return 1;	//	C
			}	else if(r == 1)	{
				return 2;	//	G
			}	else if(r == 3)	{
				return 3;	//	T or U
			}
		}	else if(s == 'D')	{
			r = ((int) rand()) % 3;
			if(r == 0)	{
				return 0;	//	A
			}	else if(r == 1)	{
				return 2;	//	G
			}	else if(r == 3)	{
				return 3;	//	T or U
			}
		}	else if(s == 'H')	{
			r = ((int) rand()) % 3;
			if(r == 0)	{
				return 0;	//	A
			}	else if(r == 1)	{
				return 1;	//	C
			}	else if(r == 3)	{
				return 3;	//	T or U
			}
		}	else if(s == 'V')	{
			r = ((int) rand()) % 3;
			if(r == 0)	{
				return 0;	//	A
			}	else if(r == 1)	{
				return 1;	//	C
			}	else if(r == 3)	{
				return 2;	//	G
			}
		}	else if(s == 'N')	{
			return (((int) rand()) % 4);	// any
		}	else	{
			cout << "error: unrecognized (not found in IPUAC) character in RNA sequence!" << endl;
			exit(0);
		}
	}
	
	int bpHash(char a, char b)	{
		return (a * 4 + b);
	}
};

