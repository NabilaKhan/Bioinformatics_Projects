#include <iostream>
#include <string>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include "assert.h"
#include "Parameters.h"

using namespace std;

class SequenceAlignment{
	public:
	//	parameters
	Parameters Score;
	//	the sequences to be aligned
	string SeqA, SeqB;
	//	whether the entire alignment score table need to be recorded
	bool recordTable;
	//	the last place the operation is appended to Sapp
	int last, saptag;
	
	//	used for suqare space alignment when all scores need to be recorded
	//	the edge scores used to reconstruct alignments
	vector< vector<int> > alnScore;
	
	//	constructor
	SequenceAlignment(bool record, string A, string B, Parameters P);
	//	destructor
	~SequenceAlignment();
	char int2char(int k);
	int ALIGN(void);
	int align(string A, string B, int tb, int te);
	void TraceBack(string &alnA, string &alnB, string &symbol);
	int ComputeScore(void);
	
	int Max(int a, int b){
		return ((a > b) ? a : b); 
	}
	
	void DEL(int k)	{
		if	(last < 0)	{				
    		last = Sapp[saptag - 1] -= (k);
    	}	else	{					
    		last = Sapp[saptag ++] = -(k);
    	}		
	}
	
	void INS(int k)	{
		if	(last < 0)	{ 
			Sapp[saptag - 1] = (k); 
			Sapp[saptag ++] = last; 
		}	else	{
			last = Sapp[saptag ++] = (k);
		}
	}
	
	void REP(void)	{
		last = Sapp[saptag ++] = 0;
	}	
	
	int GAP(int l, int g, int h)	{
		if	(l > 0)	{
			return g + l * h;
		}	else if(l == 0)	{
			return 0;
		}
	}
	private:
	//	used for linear space alignment
	vector<int> CC;	//	the optimal score and the score comes from up
	vector<int> DD;	//	the score comes from left
	vector<int> SS;
	vector<int> RR;
	//	the operation array
	vector<int> Sapp;
	

};
